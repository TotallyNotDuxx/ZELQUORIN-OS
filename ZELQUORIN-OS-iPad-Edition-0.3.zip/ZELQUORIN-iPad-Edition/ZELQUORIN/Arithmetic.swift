import Foundation

enum Arithmetic {
    enum Failure: Error { case invalid }
    static func evaluate(_ text: String) throws -> Double {
        var p = Parser(tokens:Array(text.replacingOccurrences(of:"×",with:"*").replacingOccurrences(of:"÷",with:"/").replacingOccurrences(of:"−",with:"-").filter{!$0.isWhitespace}))
        guard p.tokens.count <= 160 else {throw Failure.invalid}
        let result=try p.expression()
        guard p.index==p.tokens.count,result.isFinite else{throw Failure.invalid};return result
    }
    private struct Parser {
        let tokens:[Character]; var index=0
        mutating func take(_ c:Character)->Bool {guard index<tokens.count,tokens[index]==c else{return false};index+=1;return true}
        mutating func expression() throws -> Double {var x=try term();while true{if take("+"){x += try term()}else if take("-"){x -= try term()}else{return x}}}
        mutating func term() throws -> Double {var x=try factor();while true{if take("*"){x *= try factor()}else if take("/"){let y=try factor();guard y != 0 else{throw Failure.invalid};x /= y}else{return x}}}
        mutating func factor() throws -> Double {if take("-"){return try -factor()};if take("+"){return try factor()};if take("("){let v=try expression();guard take(")") else{throw Failure.invalid};return v};let start=index;while index<tokens.count,(tokens[index].isASCII && tokens[index].isNumber || tokens[index]=="."){index+=1};guard index>start,let v=Double(String(tokens[start..<index])) else{throw Failure.invalid};return v}
    }
}

// Pure geometry in the fixed workspace coordinate space; also tested on Linux.
enum WindowGeometry {
    static func fit(_ rect: CGRect, in bounds: CGSize) -> CGRect {
        let bw = max(1, bounds.width), bh = max(1, bounds.height)
        let w = min(bw, max(min(320, bw), rect.width))
        let h = min(bh, max(min(280, bh), rect.height))
        return CGRect(x: min(max(0, rect.minX), bw-w), y: min(max(0, rect.minY), bh-h), width: w, height: h)
    }
    static func moved(_ start: CGRect, by delta: CGSize) -> CGRect { start.offsetBy(dx: delta.width, dy: delta.height) }
    static func resized(_ start: CGRect, by delta: CGSize) -> CGRect { CGRect(origin: start.origin, size: CGSize(width: max(1,start.width+delta.width), height: max(1,start.height+delta.height))) }
    static func resized(_ start: CGRect, by delta: CGSize, in bounds: CGSize) -> CGRect {
        let base = fit(start, in: bounds)
        let maxWidth = max(1, bounds.width - base.minX), maxHeight = max(1, bounds.height - base.minY)
        let width = min(maxWidth, max(min(320,maxWidth), base.width + delta.width))
        let height = min(maxHeight, max(min(280,maxHeight), base.height + delta.height))
        return CGRect(origin: base.origin, size: CGSize(width: width, height: height))
    }
}
