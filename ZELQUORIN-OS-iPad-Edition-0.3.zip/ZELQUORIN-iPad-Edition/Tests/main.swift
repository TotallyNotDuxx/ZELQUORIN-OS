import Foundation
let valid:[(String,Double)] = [("2+3×4",14),("(2+3)×4",20),("-2×-3",6),("8÷2÷2",2),("1.5+2.25",3.75),("−4+7",3),("+4",4),(" 2 + 2 ",4)]
for (text, expected) in valid { let v = try Arithmetic.evaluate(text); precondition(abs(v-expected)<0.000001,text) }
for text in ["1/0","2+","(2+3","abc","1.2.3","", "2  +  )"] { do { _ = try Arithmetic.evaluate(text); fatalError("Unexpected success: \(text)") } catch {} }
print("15 arithmetic tests passed")
let bounds = CGSize(width: 1100, height: 720)
let rect = CGRect(x: 200, y: 100, width: 600, height: 450)
precondition(WindowGeometry.fit(rect, in: bounds) == rect)
precondition(WindowGeometry.fit(WindowGeometry.moved(rect, by: CGSize(width: 100, height: 50)), in: bounds) == CGRect(x: 300,y: 150,width: 600,height: 450))
precondition(WindowGeometry.fit(WindowGeometry.moved(rect, by: CGSize(width: -999,height: -999)), in: bounds).origin == .zero)
precondition(WindowGeometry.fit(WindowGeometry.moved(rect, by: CGSize(width: 999,height: 999)), in: bounds).origin == CGPoint(x: 500,y: 270))
precondition(WindowGeometry.fit(WindowGeometry.resized(rect, by: CGSize(width: 50,height: 60)), in: bounds).size == CGSize(width: 650,height: 510))
precondition(WindowGeometry.fit(WindowGeometry.resized(rect, by: CGSize(width: -900,height: -900)), in: bounds).size == CGSize(width: 320,height: 280))
precondition(WindowGeometry.fit(rect, in: CGSize(width: 200,height: 150)) == CGRect(x: 0,y: 0,width: 200,height: 150))
// The gesture delta is always relative to the original rectangle, not accumulated.
let delta = CGSize(width: 30,height: 15)
precondition(WindowGeometry.moved(rect, by: delta) == WindowGeometry.moved(rect, by: delta))
precondition(WindowGeometry.resized(rect, by: CGSize(width: 999,height: 999), in: bounds) == CGRect(x: 200,y: 100,width: 900,height: 620))
precondition(WindowGeometry.resized(rect, by: CGSize(width: -999,height: -999), in: bounds) == CGRect(x: 200,y: 100,width: 320,height: 280))
print("10 window geometry checks passed")
