import Foundation
let valid:[(String,Double)] = [("2+3×4",14),("(2+3)×4",20),("-2×-3",6),("8÷2÷2",2),("1.5+2.25",3.75),("−4+7",3),("+4",4),(" 2 + 2 ",4)]
for (text, expected) in valid { let v = try Arithmetic.evaluate(text); precondition(abs(v-expected)<0.000001,text) }
for text in ["1/0","2+","(2+3","abc","1.2.3","", "2  +  )"] { do { _ = try Arithmetic.evaluate(text); fatalError("Unexpected success: \(text)") } catch {} }
print("15 arithmetic tests passed")
