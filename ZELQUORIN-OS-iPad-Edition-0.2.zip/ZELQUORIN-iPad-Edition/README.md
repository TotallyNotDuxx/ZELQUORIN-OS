# ZELQUORIN OS — iPad Edition 0.2
A native SwiftUI tablet workspace for iPadOS 17 or newer, targeting the 13-inch M4 iPad Pro. This is an application, not a replacement operating system. The new bundle identifier is `com.zelquorin.workspace.tablet`; previous NOVA app data does not automatically migrate.

## What changed
- New name, grayscale app icon, and the approved emblem assets (cropped and contrast-adjusted from supplied preview frames; the source is low resolution).
- Startup: emblem plus ZELQUORIN name. Closing: emblem alone. Both use a 10-second time-based animation (2 seconds fade in, 6 seconds shine, 2 seconds fade out), with two original synthesized audio cues. TimelineView requests up to 120 Hz, but iPadOS determines actual refresh rate. System Reduce Motion removes the moving shine. Sound switches are in Settings. Audio respects the ambient audio session.
- Startup automatically runs on cold launch and return from the background. Control Center > Shut down workspace plays the closing sequence, then shows a black screen with a power button to restart the workspace. It does not force quit the app. iPadOS can interrupt animations when backgrounded or terminated.
- Browser: WebKit, 12 tabs, HTTPS address/search bar, back/forward, reload, search engine choice, persistent bookmarks/history, supported downloads saved to ZELQUORIN Files. Downloads are ordinary files, not installable code. No permission bypasses.
- App Store: Apple catalog search, ratings/prices, favorites, official StoreKit product pages and an official external-page fallback. The catalog is conservatively filtered to 4+, 9+, 12+, 13+ ratings, and Apple controls downloads, purchases, age/permission checks and launching apps. No direct installation or embedding of other iPadOS apps. Catalog country is inferred from device locale; the actual store is determined by Apple.
- ZELQUORIN Store: enable/remove three prebundled optional native modules (Focus Timer, Unit Converter, Tile Puzzle). Library opens them directly. No arbitrary executable downloads. Apple favorites are store links, not installed-app detection; supported universal link shortcuts are provided for Maps and Music.
- Retains the existing desktop, in-app window manager, dock, control center, Notes, Files, Calculator, Clock, Sketch and system information. Notes and local files persist; temporary window state may reset on close.

## Build on a Mac
1. Extract this ZIP. Open `ZELQUORIN.xcodeproj` using Xcode 16 or newer. Use a current Xcode release compatible with your iPadOS version.
2. Select the ZELQUORIN target > Signing & Capabilities. Choose an authorized Apple development team, and adjust the bundle identifier if necessary. Do not share credentials or signing keys.
3. Select an iPad simulator and click Run to check the interface. Then select your connected iPad for normal device deployment using Apple's supported signing and provisioning workflow.
4. For an IPA, use Xcode's Product > Archive and an available authorized development distribution option. Direct Xcode deployment is generally simpler.

## Build using GitHub Actions
Upload the **contents** of this project folder, including the hidden `.github/workflows/build.yml`, into your own repository. In Actions, select **Build ZELQUORIN for iPad** and run the workflow. If successful, download `ZELQUORIN-iPad-unsigned` from the run's artifacts. It contains an unsigned IPA requiring valid signing and provisioning. The included workflow has not been executed here; if it fails, inspect the build log. Normal device protections remain in force.

## Verification and limitations
Linux validation: Swift syntax parsing of all source files; 15 arithmetic tests; checked assets, source references, and archive integrity. No iOS SDK/Xcode is installed here, so native compilation, signing, StoreKit behavior, browser behavior, animations/sound and physical iPad testing are unverified. This archive is source, not a compiled IPA. iPadOS controls the real launch screen, home screen, permissions, app restrictions and termination. Export important local data before uninstalling. No system restrictions are removed.
