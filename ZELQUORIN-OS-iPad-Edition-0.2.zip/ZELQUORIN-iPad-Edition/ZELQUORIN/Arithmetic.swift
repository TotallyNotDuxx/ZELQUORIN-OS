import Foundation

enum Arithmetic {
    enum Failure: Error { case invalid }
    static func evaluate(_ text: String) throws -> Double {
        var p = Parser(tokens:Array(text.replacingOccurrences(of:"×",with:"*").replacingOccurrences(of:"÷",with:"/").replacingOccurrences(of:"−",with:"-").filter{!$0.isWhitespace}))
        guard p.tokens.count <= 160 else {throw Failure.invalid}
        let result=try p.expression()
        guard p.index==p.tokens.count,result.isFinite else{throw Failure.invalid};return result
    }
    private struct Parser {
        let tokens:[Character]; var index=0
        mutating func take(_ c:Character)->Bool {guard index<tokens.count,tokens[index]==c else{return false};index+=1;return true}
        mutating func expression() throws -> Double {var x=try term();while true{if take("+"){x += try term()}else if take("-"){x -= try term()}else{return x}}}
        mutating func term() throws -> Double {var x=try factor();while true{if take("*"){x *= try factor()}else if take("/"){let y=try factor();guard y != 0 else{throw Failure.invalid};x /= y}else{return x}}}
        mutating func factor() throws -> Double {if take("-"){return try -factor()};if take("+"){return try factor()};if take("("){let v=try expression();guard take(")") else{throw Failure.invalid};return v};let start=index;while index<tokens.count,(tokens[index].isASCII && tokens[index].isNumber || tokens[index]=="."){index+=1};guard index>start,let v=Double(String(tokens[start..<index])) else{throw Failure.invalid};return v}
    }
}
