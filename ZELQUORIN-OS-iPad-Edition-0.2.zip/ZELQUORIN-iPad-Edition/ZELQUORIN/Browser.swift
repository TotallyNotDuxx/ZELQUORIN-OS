import SwiftUI
import WebKit
import UIKit

extension Notification.Name { static let zelquorinFilesChanged = Notification.Name("zelquorin.files.changed") }
struct WebEntry: Codable, Identifiable, Equatable {
    var id: String { url }
    let url: String
    let title: String
}
struct BrowserApp: View {
    @StateObject private var session = BrowserSession()
    @State private var panel = false
    @AppStorage("zelquorin.browser.search") private var engine = "Google"
    var body: some View {
        VStack(spacing: 0) {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 6) {
                    ForEach(session.tabs) { tab in
                        HStack(spacing: 6) {
                            Button { session.select(tab.id) } label: { Text(tab.title).lineLimit(1).frame(width: 105) }
                            Button { session.close(tab.id) } label: { Image(systemName: "xmark").font(.caption) }.accessibilityLabel("Close tab")
                        }.padding(8).background(session.selected == tab.id ? Color.accentColor.opacity(0.25) : Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 8))
                    }
                    Button { session.add() } label: { Image(systemName: "plus.circle").font(.title2) }.disabled(session.tabs.count >= 12).accessibilityLabel("New tab")
                }.padding(8)
            }
            HStack(spacing: 10) {
                Button { session.current?.web.goBack() } label: { Image(systemName: "chevron.left") }.disabled(!session.back).accessibilityLabel("Back")
                Button { session.current?.web.goForward() } label: { Image(systemName: "chevron.right") }.disabled(!session.forward).accessibilityLabel("Forward")
                Button { if session.loading { session.current?.web.stopLoading() } else { session.current?.web.reload() } } label: { Image(systemName: session.loading ? "xmark" : "arrow.clockwise") }.accessibilityLabel("Reload or stop")
                TextField("Search or enter HTTPS address", text: $session.address).textFieldStyle(.roundedBorder).keyboardType(.webSearch).textInputAutocapitalization(.never).autocorrectionDisabled().onSubmit { session.navigate(engine: engine) }
                Button("Go") { session.navigate(engine: engine) }.buttonStyle(.bordered)
                Menu {
                    Button("Bookmark page", systemImage: "bookmark") { session.bookmark() }
                    Button("History, bookmarks & downloads", systemImage: "books.vertical") { panel = true }
                    Picker("Search engine", selection: $engine) { ForEach(["Google", "Bing", "DuckDuckGo"], id: \.self) { Text($0) } }
                    if let url = session.current?.web.url, url.scheme == "https" { ShareLink(item: url) { Label("Share page", systemImage: "square.and.arrow.up") }; Link("Open in system browser", destination: url) }
                } label: { Image(systemName: "ellipsis.circle").font(.title2) }.accessibilityLabel("Browser menu")
            }.padding(8)
            if session.loading { ProgressView().progressViewStyle(.linear) }
            if !session.status.isEmpty { Text(session.status).font(.caption).foregroundStyle(.secondary).padding(6) }
            if let tab = session.current {
                if tab.web.url == nil && !session.loading {
                    VStack(spacing: 14) { Image(systemName: "globe").font(.system(size: 46, weight: .thin)); Text("ZELQUORIN Browser").font(.title.bold()); Text("Search the web or enter a website above.").foregroundStyle(.secondary); Text("WebKit • iPadOS security and permissions still apply").font(.caption).foregroundStyle(.secondary) }.frame(maxWidth: .infinity, maxHeight: .infinity)
                } else { BrowserSurface(web: tab.web).id(tab.id).frame(maxWidth: .infinity, maxHeight: .infinity) }
            }
        }.sheet(isPresented: $panel) {
            NavigationStack { List {
                Section("Bookmarks") { if session.bookmarks.isEmpty { Text("No bookmarks yet").foregroundStyle(.secondary) }; ForEach(session.bookmarks) { entry in Button(entry.title) { session.open(entry.url); panel = false } } }
                Section("History") { if session.history.isEmpty { Text("No pages visited yet").foregroundStyle(.secondary) }; ForEach(session.history) { entry in Button(entry.title) { session.open(entry.url); panel = false } } }
                Section("Downloads") { Text("Completed downloads appear in ZELQUORIN Files. Export them using the share button.").font(.callout); ForEach(session.completed, id: \.self) { url in if FileManager.default.fileExists(atPath: url.path) { ShareLink(item: url) { Label(url.lastPathComponent, systemImage: "doc") } } }; if session.completed.isEmpty { Text("No downloads in this session").foregroundStyle(.secondary) } }
            }.navigationTitle("Browser library").toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { panel = false } } } }
        }
    }
}
struct BrowserSurface: UIViewRepresentable {
    let web: WKWebView
    func makeUIView(context: Context) -> WKWebView { web }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}
final class BrowserTab: Identifiable {
    let id = UUID()
    let web: WKWebView
    var title = "New tab"
    init() { let config = WKWebViewConfiguration(); config.websiteDataStore = .default(); web = WKWebView(frame: .zero, configuration: config) }
}
final class BrowserSession: NSObject, ObservableObject, WKNavigationDelegate, WKUIDelegate, WKDownloadDelegate {
    @Published var tabs: [BrowserTab] = []
    @Published var selected = UUID()
    @Published var address = ""
    @Published var loading = false
    @Published var back = false
    @Published var forward = false
    @Published var status = ""
    @Published var bookmarks: [WebEntry] = []
    @Published var history: [WebEntry] = []
    @Published var completed: [URL] = []
    private var destinations: [ObjectIdentifier: URL] = [:]
    private var downloads: [WKDownload] = []
    var current: BrowserTab? { tabs.first { $0.id == selected } }
    override init() { super.init(); bookmarks = read("zelquorin.browser.bookmarks"); history = read("zelquorin.browser.history"); add() }
    private func read(_ key: String) -> [WebEntry] { guard let data = UserDefaults.standard.data(forKey: key) else { return [] }; return (try? JSONDecoder().decode([WebEntry].self, from: data)) ?? [] }
    private func persist(_ values: [WebEntry], _ key: String) { if let data = try? JSONEncoder().encode(values) { UserDefaults.standard.set(data, forKey: key) } }
    func add() { guard tabs.count < 12 else { return }; let tab = BrowserTab(); tab.web.navigationDelegate = self; tab.web.uiDelegate = self; tabs.append(tab); select(tab.id) }
    func select(_ id: UUID) { selected = id; sync(); status = "" }
    func close(_ id: UUID) { tabs.first { $0.id == id }?.web.stopLoading(); tabs.removeAll { $0.id == id }; if tabs.isEmpty { add() } else if selected == id { select(tabs.last!.id) } }
    func sync() { address = current?.web.url?.absoluteString ?? ""; loading = current?.web.isLoading ?? false; back = current?.web.canGoBack ?? false; forward = current?.web.canGoForward ?? false }
    func navigate(engine: String) {
        let raw = address.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !raw.isEmpty else { return }
        if raw.contains("://") { open(raw); return }
        if !raw.contains(where: { $0.isWhitespace }), raw.contains(".") { open("https://" + raw); return }
        let base = engine == "Bing" ? "https://www.bing.com/search" : engine == "DuckDuckGo" ? "https://duckduckgo.com/" : "https://www.google.com/search"
        var components = URLComponents(string: base); components?.queryItems = [URLQueryItem(name: "q", value: raw)]
        if let url = components?.url { open(url.absoluteString) }
    }
    func open(_ raw: String) { guard let url = URL(string: raw), url.scheme?.lowercased() == "https", let host = url.host, !host.isEmpty, url.user == nil, url.password == nil else { status = "Enter a valid HTTPS website."; return }; status = ""; loading = true; current?.web.load(URLRequest(url: url)) }
    func bookmark() { guard let web = current?.web, let url = web.url, url.scheme == "https" else { return }; let entry = WebEntry(url: url.absoluteString, title: web.title ?? url.absoluteString); bookmarks.removeAll { $0.url == entry.url }; bookmarks.insert(entry, at: 0); persist(bookmarks, "zelquorin.browser.bookmarks"); status = "Bookmark saved" }
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) { if current?.web === webView { loading = true; status = "" } }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        if let tab = tabs.first(where: { $0.web === webView }) { tab.title = webView.title ?? "Website"; objectWillChange.send() }
        if let url = webView.url, url.scheme == "https" { let entry = WebEntry(url: url.absoluteString, title: webView.title ?? url.absoluteString); history.removeAll { $0.url == entry.url }; history.insert(entry, at: 0); history = Array(history.prefix(200)); persist(history, "zelquorin.browser.history") }
        if current?.web === webView { sync(); loading = false }
    }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { failed(webView, error) }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { failed(webView, error) }
    private func failed(_ web: WKWebView, _ error: Error) { if current?.web === web { loading = false; if (error as NSError).code != NSURLErrorCancelled { status = error.localizedDescription } } }
    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let scheme = action.request.url?.scheme?.lowercased(), ["https", "about", "blob"].contains(scheme) else { status = "Only secure web navigation is supported."; decisionHandler(.cancel); return }
        decisionHandler(action.shouldPerformDownload ? .download : .allow)
    }
    func webView(_ webView: WKWebView, decidePolicyFor response: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) { decisionHandler(response.canShowMIMEType ? .allow : .download) }
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? { if navigationAction.targetFrame == nil, navigationAction.navigationType == .linkActivated, let url = navigationAction.request.url, url.scheme == "https", tabs.count < 12 { add(); open(url.absoluteString) }; return nil }
    func webView(_ webView: WKWebView, navigationAction: WKNavigationAction, didBecome download: WKDownload) { accept(download) }
    func webView(_ webView: WKWebView, navigationResponse: WKNavigationResponse, didBecome download: WKDownload) { accept(download) }
    private func accept(_ download: WKDownload) { downloads.append(download); download.delegate = self; loading = false; status = "Downloading…" }
    func download(_ download: WKDownload, decideDestinationUsing response: URLResponse, suggestedFilename: String, completionHandler: @escaping (URL?) -> Void) {
        let name = (suggestedFilename as NSString).lastPathComponent.replacingOccurrences(of: "/", with: "_")
        guard !name.isEmpty, name != ".", name != ".." else { completionHandler(nil); return }
        // Downloads are files only. Never execute or install them.
        let folder = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("ZELQUORIN Files", isDirectory: true)
        do { try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true); let path = folder.appendingPathComponent(String(UUID().uuidString.prefix(8)) + "-" + name); destinations[ObjectIdentifier(download)] = path; completionHandler(path) }
        catch { status = error.localizedDescription; completionHandler(nil) }
    }
    func downloadDidFinish(_ download: WKDownload) { if let url = destinations.removeValue(forKey: ObjectIdentifier(download)) { completed.insert(url, at: 0); status = "Saved to ZELQUORIN Files: \(url.lastPathComponent)"; NotificationCenter.default.post(name: .zelquorinFilesChanged, object: nil) }; downloads.removeAll { $0 === download } }
    func download(_ download: WKDownload, didFailWithError error: Error, resumeData: Data?) { if let url = destinations.removeValue(forKey: ObjectIdentifier(download)) { try? FileManager.default.removeItem(at: url) }; downloads.removeAll { $0 === download }; status = error.localizedDescription }
}
