import SwiftUI
import StoreKit
import UIKit

struct AppleProduct: Codable, Identifiable {
    let trackId: Int
    let trackName: String
    let artistName: String?
    let formattedPrice: String?
    let averageUserRating: Double?
    let trackViewUrl: String?
    let contentAdvisoryRating: String?
    var id: Int { trackId }
    var officialURL: URL { URL(string: "https://apps.apple.com/app/id\(trackId)")! }
}
private struct CatalogResponse: Decodable { let results: [AppleProduct] }

// Only prebundled native modules, never downloaded executable code.
enum WorkspaceModule: String, CaseIterable, Identifiable {
    case focus = "Focus Timer", converter = "Unit Converter", puzzle = "Tile Puzzle"
    var id: String { rawValue }
    var icon: String { switch self { case .focus: return "timer"; case .converter: return "arrow.left.arrow.right"; case .puzzle: return "square.grid.3x3" } }
    var detail: String { switch self { case .focus: return "Set a focus countdown."; case .converter: return "Convert length and temperature."; case .puzzle: return "Reorder a sliding number puzzle." } }
}
private func installedModules(_ value: String) -> Set<String> { Set(value.split(separator: "|").map(String.init)) }
private func toggleModule(_ module: WorkspaceModule, _ value: String) -> String { var items = installedModules(value); if items.contains(module.id) { items.remove(module.id) } else { items.insert(module.id) }; return items.sorted().joined(separator: "|") }

struct ZelquorinStoreView: View {
    @State private var tab = 0
    @State private var query = ""
    @State private var results: [AppleProduct] = []
    @State private var status = "Search Apple's iPad app catalog."
    @State private var loading = false
    @State private var request: Task<Void, Never>?
    @State private var storeError: String?
    @AppStorage("zelquorin.store.modules") private var modules = ""
    @AppStorage("zelquorin.store.favorites") private var favorites = Data()
    private var saved: [AppleProduct] { (try? JSONDecoder().decode([AppleProduct].self, from: favorites)) ?? [] }
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Picker("Store", selection: $tab) { Text("Apple App Store").tag(0); Text("ZELQUORIN Store").tag(1) }.pickerStyle(.segmented)
            if tab == 0 {
                HStack { TextField("Search iPad apps", text: $query).textFieldStyle(.roundedBorder).onSubmit(search); Button("Search", action: search).buttonStyle(.borderedProminent).disabled(query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty) }
                Text("Apple controls installations, purchases and permissions. Apps open outside this workspace.").font(.caption).foregroundStyle(.secondary)
                if loading { ProgressView() }
                Text(status).font(.caption).foregroundStyle(.secondary)
                ScrollView { LazyVStack(alignment: .leading, spacing: 10) {
                    ForEach(results) { product in
                        VStack(alignment: .leading, spacing: 6) {
                            HStack { Image(systemName: "app.badge").font(.title2); VStack(alignment: .leading) { Text(product.trackName).font(.headline); Text(product.artistName ?? "Developer").font(.caption).foregroundStyle(.secondary) }; Spacer(); Text(product.formattedPrice ?? "See App Store").font(.caption) }
                            HStack {
                                if let rating = product.averageUserRating { Text(String(format: "★ %.1f", rating)).font(.caption) }
                                if let age = product.contentAdvisoryRating { Text(age).font(.caption).foregroundStyle(.secondary) }
                                Spacer()
                                Button { showApple(product) } label: { Text("View") }.buttonStyle(.borderedProminent)
                                Button { var items = saved; if items.contains(where: { $0.id == product.id }) { items.removeAll { $0.id == product.id } } else { items.append(product) }; favorites = (try? JSONEncoder().encode(items)) ?? Data() } label: { Image(systemName: saved.contains(where: { $0.id == product.id }) ? "star.fill" : "star") }.accessibilityLabel("Toggle favorite")
                            }
                        }.padding(12).background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 12))
                    }
                } }
            } else {
                Text("Enable optional apps bundled with ZELQUORIN. Open them from Library. No executable downloads.").font(.caption).foregroundStyle(.secondary)
                ScrollView { VStack(spacing: 12) { ForEach(WorkspaceModule.allCases) { module in HStack { Image(systemName: module.icon).font(.title2); VStack(alignment: .leading) { Text(module.rawValue).font(.headline); Text(module.detail).font(.caption).foregroundStyle(.secondary) }; Spacer(); Button(installedModules(modules).contains(module.id) ? "Remove" : "Install") { modules = toggleModule(module, modules) }.buttonStyle(.bordered) }.padding(12).background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 12)) } } }
            }
        }.padding(14).onDisappear { request?.cancel() }.alert("App Store", isPresented: Binding(get: { storeError != nil }, set: { if !$0 { storeError = nil } })) { Button("OK", role: .cancel) {} } message: { Text(storeError ?? "") }
    }
    private func search() {
        let term = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !term.isEmpty else { return }
        request?.cancel(); loading = true; results = []; status = "Searching…"
        request = Task { @MainActor in
            var url = URLComponents(string: "https://itunes.apple.com/search")!
            let country = Locale.current.region?.identifier ?? "US"
            url.queryItems = [URLQueryItem(name: "term", value: term), URLQueryItem(name: "country", value: country.lowercased()), URLQueryItem(name: "entity", value: "iPadSoftware"), URLQueryItem(name: "limit", value: "40"), URLQueryItem(name: "explicit", value: "No")]
            do {
                let (data, response) = try await URLSession.shared.data(from: url.url!)
                guard !Task.isCancelled else { return }
                guard (response as? HTTPURLResponse)?.statusCode == 200 else { throw URLError(.badServerResponse) }
                let decoded = try JSONDecoder().decode(CatalogResponse.self, from: data)
                // Conservative catalog filter; Apple separately enforces device-level purchase controls.
                results = decoded.results.filter { ["4+", "9+", "12+", "13+"].contains($0.contentAdvisoryRating ?? "") }
                status = results.isEmpty ? "No supported results. Try a different search." : "\(results.count) results from Apple"
            } catch { if Task.isCancelled { return }; status = "Catalog unavailable: \(error.localizedDescription)" }
            loading = false
        }
    }
    private func showApple(_ product: AppleProduct) {
        ApplePagePresenter.shared.show(product) { error in storeError = error }
    }
}

@MainActor final class ApplePagePresenter: NSObject, SKStoreProductViewControllerDelegate {
    static let shared = ApplePagePresenter()
    private var busy = false
    func show(_ product: AppleProduct, failure: @escaping (String) -> Void) {
        guard !busy else { return }; busy = true
        let vc = SKStoreProductViewController(); vc.delegate = self
        vc.loadProduct(withParameters: [SKStoreProductParameterITunesItemIdentifier: NSNumber(value: product.trackId)]) { [weak self] success, error in
            Task { @MainActor in
                self?.busy = false
                guard success else { UIApplication.shared.open(product.officialURL, options: [:]) { opened in if !opened { failure(error?.localizedDescription ?? "Could not open Apple's product page.") } }; return }
                guard let scene = UIApplication.shared.connectedScenes.compactMap({ $0 as? UIWindowScene }).first(where: { $0.activationState == .foregroundActive }), var presenter = scene.windows.first(where: { $0.isKeyWindow })?.rootViewController else { failure("No active window for the App Store."); return }
                while let next = presenter.presentedViewController { presenter = next }
                vc.modalPresentationStyle = .fullScreen
                presenter.present(vc, animated: true)
            }
        }
    }
    func productViewControllerDidFinish(_ viewController: SKStoreProductViewController) { viewController.dismiss(animated: true) }
}

struct ZelquorinLibraryView: View {
    @AppStorage("zelquorin.store.modules") private var modules = ""
    @AppStorage("zelquorin.store.favorites") private var favorites = Data()
    @State private var selected: WorkspaceModule?
    @State private var shortcutStatus = ""
    private var saved: [AppleProduct] { (try? JSONDecoder().decode([AppleProduct].self, from: favorites)) ?? [] }
    var body: some View {
        if let selected { VStack(alignment: .leading) { Button { self.selected = nil } label: { Label("Library", systemImage: "chevron.left") }.padding(12); Text(selected.rawValue).font(.title2.bold()).padding(.horizontal); switch selected { case .focus: FocusModule(); case .converter: ConverterModule(); case .puzzle: PuzzleModule() } } }
        else { List {
            Section("Installed workspace modules") {
                if installedModules(modules).isEmpty { Text("Install optional modules from ZELQUORIN Store.").foregroundStyle(.secondary) }
                ForEach(WorkspaceModule.allCases.filter { installedModules(modules).contains($0.id) }) { module in Button { selected = module } label: { Label(module.rawValue, systemImage: module.icon) } }
            }
            Section("Apple favorites") {
                if saved.isEmpty { Text("Star an app in the Apple catalog.").foregroundStyle(.secondary) }
                ForEach(saved) { product in HStack { Text(product.trackName); Spacer(); Button("App Store") { ApplePagePresenter.shared.show(product) { shortcutStatus = $0 } }.buttonStyle(.bordered); Button(role: .destructive) { favorites = (try? JSONEncoder().encode(saved.filter { $0.id != product.id })) ?? Data() } label: { Image(systemName: "trash") }.buttonStyle(.borderless) } }
                Text("Favorites are store shortcuts, not an inventory of installed iPad apps.").font(.caption).foregroundStyle(.secondary)
            }
            Section("Supported app shortcuts") {
                Button("Apple Maps") { openSupported("https://maps.apple.com/") }
                Button("Apple Music") { openSupported("https://music.apple.com/") }
                if !shortcutStatus.isEmpty { Text(shortcutStatus).font(.caption) }
            }
        }.scrollContentBackground(.hidden) }
    }
    private func openSupported(_ raw: String) { UIApplication.shared.open(URL(string: raw)!, options: [.universalLinksOnly: true]) { success in shortcutStatus = success ? "Opened the supported app." : "No supported installed app handled this link." } }
}

struct FocusModule: View {
    @State private var minutes = 25
    @State private var deadline: Date?
    var body: some View { TimelineView(.periodic(from: .now, by: 1)) { ctx in
        let seconds = max(0, Int((deadline?.timeIntervalSince(ctx.date) ?? Double(minutes * 60)).rounded(.up)))
        VStack(spacing: 16) { Text(String(format: "%02d:%02d", seconds/60, seconds%60)).font(.system(size: 48, design: .monospaced)); Stepper("\(minutes) minutes", value: $minutes, in: 1...120).disabled(deadline != nil); Button(deadline == nil ? "Start" : "Reset") { if deadline == nil { deadline = Date().addingTimeInterval(Double(minutes * 60)) } else { deadline = nil } }.buttonStyle(.borderedProminent) }.padding(18).frame(maxHeight: .infinity)
    } }
}
struct ConverterModule: View {
    @State private var value = "1"
    @State private var mode = "km → mi"
    var body: some View { Form { TextField("Value", text: $value).keyboardType(.numbersAndPunctuation); Picker("Conversion", selection: $mode) { ForEach(["km → mi", "mi → km", "cm → in", "°C → °F", "°F → °C"], id: \.self) { Text($0) } }; if let n = Double(value), n.isFinite { Text(convert(n), format: .number.precision(.fractionLength(0...6))).font(.title) } else { Text("Enter a number") } }.scrollContentBackground(.hidden) }
    func convert(_ n: Double) -> Double { switch mode { case "km → mi": return n/1.609344; case "mi → km": return n*1.609344; case "cm → in": return n/2.54; case "°C → °F": return n*1.8+32; default: return (n-32)/1.8 } }
}
struct PuzzleModule: View {
    @State private var tiles = [1,2,3,4,5,6,0,7,8]
    var body: some View { VStack { Text(tiles == [1,2,3,4,5,6,7,8,0] ? "Solved!" : "Slide adjacent tiles into the empty space."); LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 3), spacing: 8) { ForEach(tiles.indices, id: \.self) { i in Button { move(i) } label: { Text(tiles[i] == 0 ? "" : String(tiles[i])).font(.title).frame(maxWidth: .infinity).frame(height: 54).background(tiles[i] == 0 ? .clear : Color.accentColor.opacity(0.2), in: RoundedRectangle(cornerRadius: 8)) }.buttonStyle(.plain) } }.frame(maxWidth: 240); Button("Shuffle") { tiles = [1,2,3,4,5,6,7,8,0]; for _ in 0..<70 { let zero = tiles.firstIndex(of: 0)!; let candidates = tiles.indices.filter { adjacent($0, zero) }; if let i = candidates.randomElement() { move(i) } } }.buttonStyle(.bordered) }.padding() }
    private func adjacent(_ i: Int, _ j: Int) -> Bool { abs(i/3-j/3)+abs(i%3-j%3) == 1 }
    private func move(_ i: Int) { if let j = tiles.firstIndex(of: 0), adjacent(i,j) { tiles.swapAt(i,j) } }
}
