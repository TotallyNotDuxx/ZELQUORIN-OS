import SwiftUI
import UIKit

@main struct ZELQUORINApp: App {
    var body: some Scene { WindowGroup { Desktop().preferredColorScheme(.dark) } }
}

enum ZelquorinApp: String, CaseIterable, Identifiable {
    case notes = "Notes", files = "Files", calculator = "Calculator", settings = "Settings", browser = "Browser", clock = "Clock", system = "System", sketch = "Sketch", store = "App Store", library = "Library"
    var id: String { rawValue }
    var icon: String {
        switch self {
        case .notes: return "note.text"
        case .files: return "folder.fill"
        case .calculator: return "calculator"
        case .settings: return "gearshape.fill"
        case .browser: return "globe"
        case .clock: return "clock"
        case .system: return "cpu"
        case .sketch: return "pencil.tip.crop.circle"
        case .store: return "bag.fill"
        case .library: return "square.grid.3x3.fill"
        }
    }
}

struct ZelquorinWindow: Identifiable {
    let id = UUID()
    let app: ZelquorinApp
    var position: CGPoint
    var size: CGSize
    var minimized = false
    var maximized = false
}

struct Desktop: View {
    @AppStorage("zelquorin.accent") private var accentName = "Cyan"
    @AppStorage("zelquorin.wallpaper") private var wallpaper = "Orbit"
    @AppStorage("zelquorin.animations") private var animations = true
    @AppStorage("zelquorin.grid") private var grid = true
    @AppStorage("zelquorin.widgets") private var widgets = true
    @AppStorage("zelquorin.dock") private var dock = true
    @State private var windows: [ZelquorinWindow] = []
    @State private var launcher = false
    @State private var control = false
    @State private var search = ""
    @State private var boot = true
    @State private var closing = false
    @State private var asleep = false
    @State private var wasBackgrounded = false
    @Environment(\.scenePhase) private var scenePhase
    private var accent: Color { switch accentName { case "Violet": return .purple; case "Emerald": return .mint; case "Amber": return .orange; default: return .cyan } }
    var body: some View {
        GeometryReader { geo in
            let bounds = geo.size
            ZStack {
                background.ignoresSafeArea()
                VStack(spacing: 0) {
                    topBar
                    Spacer()
                    if dock { dockBar(bounds) }
                }
                VStack(alignment: .leading, spacing: 26) {
                    VStack(alignment: .leading, spacing: 7) {
                        Text("Z E L Q U O R I N  /  O S").font(.system(size: 13, weight: .semibold, design: .monospaced)).foregroundStyle(accent)
                        Text("Workspace 01").font(.system(size: 42, weight: .light, design: .rounded))
                        Text("YOUR DIGITAL SPACE").font(.caption.monospaced()).foregroundStyle(.secondary)
                    }
                    if widgets { TimelineView(.periodic(from: .now, by: 1)) { ctx in
                        VStack(alignment: .leading, spacing: 4) {
                            Text(ctx.date, style: .time).font(.system(size: 42, weight: .thin, design: .monospaced))
                            Text(ctx.date.formatted(date: .complete, time: .omitted)).font(.caption).foregroundStyle(.secondary)
                        }.padding(18).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22))
                    } }
                    LazyVGrid(columns: [GridItem(.fixed(94)), GridItem(.fixed(94))], alignment: .leading, spacing: 14) {
                        ForEach(ZelquorinApp.allCases) { app in appTile(app, bounds: bounds) }
                    }
                    Spacer(minLength: 0)
                }.padding(.top, 70).padding(.leading, 28).padding(.bottom, 90).frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                ForEach(windows) { win in
                    Group {
                        let w = win.maximized ? max(220,bounds.width-24) : min(win.size.width,max(220,bounds.width-24))
                        let h = win.maximized ? max(240,bounds.height-130) : min(win.size.height,max(240,bounds.height-130))
                        WindowFrame(window: win, accent: accent, width: w, height: h, move: { delta in
                            change(win.id) { $0.position.x += delta.width; $0.position.y += delta.height }
                        }, resize: { delta in
                            change(win.id) { $0.size.width = max(320,min(bounds.width-24,$0.size.width+delta.width)); $0.size.height = max(280,min(bounds.height-130,$0.size.height+delta.height)) }
                        }, focus: { focus(win.id) }, close: { windows.removeAll { $0.id == win.id } }, minimize: { change(win.id) { $0.minimized = true } }, maximize: { change(win.id) { $0.maximized.toggle() } })
                        .opacity(win.minimized ? 0 : 1).allowsHitTesting(!win.minimized).accessibilityHidden(win.minimized)
                        .position(x: win.maximized ? bounds.width/2 : max(w/2,min(bounds.width-w/2,win.position.x)), y: win.maximized ? (bounds.height-36)/2 : max(h/2+42,min(bounds.height-h/2-66,win.position.y)))
                    }
                }
                VStack { HStack { Spacer(); if control { controlPanel } }; Spacer() }.padding(.top, 52).padding(.trailing, 16)
                if launcher { launcherPanel(bounds).transition(.opacity) }
                VStack { Spacer(); if !dock { HStack { ForEach(windows.filter(\.minimized)) { win in Button { restore(win.id) } label: { Label(win.app.rawValue, systemImage: win.app.icon) }.buttonStyle(.bordered) }; Button { launcher.toggle() } label: { Label("Apps",systemImage:"square.grid.2x2") }.buttonStyle(.bordered) } } }.padding(12)
                if asleep { Color.black.ignoresSafeArea().overlay { Button { asleep = false; boot = true } label: { Image(systemName: "power").font(.largeTitle).foregroundStyle(.gray) }.accessibilityLabel("Start ZELQUORIN") }.zIndex(100) }
                if boot || closing { BootAnimation(closing: closing) { if closing { asleep = true; closing = false } else { boot = false } }.id(closing).zIndex(101) }
            }.tint(accent).animation(animations ? .easeInOut(duration: 0.18) : nil, value: launcher).animation(animations ? .easeInOut(duration: 0.18) : nil, value: control)
        }.onChange(of: scenePhase) { _, phase in
            if phase == .background { wasBackgrounded = true; boot = false; closing = false }
            if phase == .active && wasBackgrounded { wasBackgrounded = false; asleep = false; boot = true }
        }
    }
    private var background: some View {
        ZStack {
            Color(red: 0.025, green: 0.04, blue: 0.09)
            RadialGradient(colors: [accent.opacity(0.26), .clear], center: wallpaper == "Orbit" ? .bottomTrailing : .topLeading, startRadius: 20, endRadius: 850)
            if wallpaper == "Orbit" { ForEach(0..<5) { i in Circle().stroke(accent.opacity(0.13),lineWidth: 1).frame(width: CGFloat(260+i*132)).offset(x: 330,y: 100) } }
            if grid { Canvas { ctx, size in var p = Path(); stride(from: CGFloat(0), through: size.width, by: 40).forEach { x in p.move(to: CGPoint(x:x,y:0)); p.addLine(to:CGPoint(x:x,y:size.height)) }; stride(from: CGFloat(0), through: size.height, by: 40).forEach { y in p.move(to:CGPoint(x:0,y:y)); p.addLine(to:CGPoint(x:size.width,y:y)) }; ctx.stroke(p,with:.color(.white.opacity(0.035)),lineWidth:1) } }
        }
    }
    private var topBar: some View {
        HStack(spacing: 18) {
            Button { launcher.toggle(); control = false } label: { Label("ZELQUORIN",systemImage:"sparkle").font(.headline.monospaced()) }
            Text("WORKSPACE / 01").font(.caption.monospaced()).foregroundStyle(.secondary)
            Spacer()
            TimelineView(.periodic(from:.now,by:1)) { ctx in Text(ctx.date,style:.time).font(.callout.monospacedDigit()) }
            Button { control.toggle(); launcher = false } label: { Image(systemName:"slider.horizontal.3").font(.title3) }.accessibilityLabel("Control center")
        }.padding(.horizontal,22).frame(height:48).background(.ultraThinMaterial)
    }
    private func dockBar(_ bounds: CGSize) -> some View {
        GeometryReader { g in
            ScrollView(.horizontal,showsIndicators:false) {
                HStack(spacing: 14) {
                    Button { launcher.toggle(); control = false } label: { Image(systemName:"square.grid.2x2.fill").font(.title2).frame(width:44,height:44) }.accessibilityLabel("All apps")
                    Divider().frame(height: 32)
                    ForEach(ZelquorinApp.allCases) { app in Button { open(app, bounds: bounds) } label: { VStack(spacing: 3) { Image(systemName:app.icon).font(.title2).frame(width:44,height:34); Circle().fill(windows.contains{$0.app == app} ? accent : .clear).frame(width:4,height:4) } }.accessibilityLabel(app.rawValue) }
                }.padding(8).padding(.horizontal,10)
            }.fixedSize(horizontal:false,vertical:true).frame(maxWidth:640).background(.ultraThinMaterial,in:RoundedRectangle(cornerRadius:22)).overlay(RoundedRectangle(cornerRadius:22).strokeBorder(accent.opacity(0.22))).frame(maxWidth:.infinity)
        }.frame(height:70).padding(.horizontal,14).padding(.bottom,5)
    }
    private func appTile(_ app: ZelquorinApp, bounds: CGSize) -> some View {
        Button { open(app,bounds:bounds) } label: { VStack(spacing:8) { Image(systemName:app.icon).font(.system(size:26,weight:.light)).frame(width:58,height:58).background(accent.opacity(0.10),in:RoundedRectangle(cornerRadius:17)).overlay(RoundedRectangle(cornerRadius:17).strokeBorder(accent.opacity(0.35))); Text(app.rawValue).font(.caption).foregroundStyle(.white) }.frame(width:90) }.buttonStyle(.plain).accessibilityLabel("Open \(app.rawValue)")
    }
    private func launcherPanel(_ bounds: CGSize) -> some View {
        ZStack { Color.black.opacity(0.55).ignoresSafeArea().onTapGesture { launcher = false }; VStack(alignment:.leading,spacing:20) { HStack { Text("Application library").font(.title2.bold()); Spacer(); Button { launcher=false } label: { Image(systemName:"xmark.circle.fill").font(.title2) }.accessibilityLabel("Close launcher") }; TextField("Search apps",text:$search).textFieldStyle(.roundedBorder); LazyVGrid(columns:[GridItem(.adaptive(minimum:90))],spacing:18) { ForEach(ZelquorinApp.allCases.filter{search.isEmpty || $0.rawValue.localizedCaseInsensitiveContains(search)}) { app in appTile(app,bounds:bounds) } } }.padding(24).frame(maxWidth:520).background(.regularMaterial,in:RoundedRectangle(cornerRadius:28)).padding(20) }
    }
    private var controlPanel: some View {
        VStack(alignment:.leading,spacing:16) { Text("CONTROL CENTER").font(.caption.monospaced()).foregroundStyle(accent); Toggle("Interface animations",isOn:$animations); Toggle("Desktop grid",isOn:$grid); Toggle("Widgets",isOn:$widgets); Toggle("Dock",isOn:$dock); Picker("Accent",selection:$accentName) { ForEach(["Cyan","Violet","Emerald","Amber"],id:\.self){Text($0)} }; Button { control = false; closing = true } label: { Label("Shut down workspace", systemImage: "power") }.buttonStyle(.bordered); Text("Workspace controls only • iPadOS manages device settings.").font(.caption).foregroundStyle(.secondary) }.padding(20).frame(width:310).background(.regularMaterial,in:RoundedRectangle(cornerRadius:20))
    }
    private func open(_ app: ZelquorinApp,bounds:CGSize) { launcher=false; control=false; search=""; if let win=windows.first(where:{$0.app == app}) { restore(win.id); return }; let n=CGFloat(windows.count % 4)*22; windows.append(ZelquorinWindow(app:app,position:CGPoint(x:bounds.width/2+n,y:bounds.height/2-10+n),size:CGSize(width:min(720,bounds.width-30),height:min(540,max(300,bounds.height-140))))) }
    private func change(_ id:UUID,_ fn:(inout ZelquorinWindow)->Void) { if let index=windows.firstIndex(where:{$0.id==id}) { fn(&windows[index]) } }
    private func focus(_ id:UUID) { if let i=windows.firstIndex(where:{$0.id==id}), i != windows.count-1 { let win=windows.remove(at:i); windows.append(win) } }
    private func restore(_ id:UUID) { change(id){$0.minimized=false}; focus(id) }
}

struct WindowFrame: View {
    let window:ZelquorinWindow; let accent:Color; let width:CGFloat; let height:CGFloat
    let move:(CGSize)->Void; let resize:(CGSize)->Void; let focus:()->Void; let close:()->Void; let minimize:()->Void; let maximize:()->Void
    @GestureState private var drag:CGSize = .zero
    @GestureState private var sizing:CGSize = .zero
    var body: some View {
        VStack(spacing:0) {
            HStack(spacing:12) { Image(systemName:window.app.icon).foregroundStyle(accent); Text(window.app.rawValue).font(.headline); Spacer(); Button(action:minimize){Image(systemName:"minus.circle")}.accessibilityLabel("Minimize"); Button(action:maximize){Image(systemName:window.maximized ? "arrow.down.right.and.arrow.up.left" : "arrow.up.left.and.arrow.down.right")}.accessibilityLabel("Toggle maximize"); Button(action:close){Image(systemName:"xmark.circle.fill").foregroundStyle(.pink)}.accessibilityLabel("Close") }.padding(.horizontal,14).frame(height:44).background(accent.opacity(0.09)).contentShape(Rectangle()).onTapGesture(perform:focus).gesture(DragGesture().updating($drag){v,s,_ in if !window.maximized {s=v.translation}}.onEnded{v in focus(); if !window.maximized { move(v.translation) }})
            Divider()
            content.frame(maxWidth:.infinity,maxHeight:.infinity)
            if !window.maximized { HStack { Spacer(); Image(systemName:"arrow.down.right").font(.caption).padding(9).contentShape(Rectangle()).gesture(DragGesture().updating($sizing){v,s,_ in s=v.translation}.onEnded{v in focus();resize(v.translation)}) } }
        }.frame(width:max(220,width+sizing.width),height:max(240,height+sizing.height)).background(Color(red:0.055,green:0.075,blue:0.13),in:RoundedRectangle(cornerRadius:18)).clipShape(RoundedRectangle(cornerRadius:18)).overlay(RoundedRectangle(cornerRadius:18).strokeBorder(accent.opacity(0.35))).shadow(color:.black.opacity(0.55),radius:24,y:12).offset(drag).offset(x:sizing.width/2,y:sizing.height/2)
    }
    @ViewBuilder var content:some View { switch window.app { case .notes: NotesApp(); case .files: FilesApp(); case .calculator: CalculatorApp(); case .settings: SettingsApp(); case .browser: BrowserApp(); case .clock: ClockApp(); case .system: SystemApp(); case .sketch: SketchApp(); case .store: ZelquorinStoreView(); case .library: ZelquorinLibraryView() } }
}
