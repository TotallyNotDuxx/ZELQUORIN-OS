import SwiftUI
import UIKit

@main struct ZELQUORINApp: App {
    var body: some Scene { WindowGroup { Desktop().preferredColorScheme(.dark).statusBarHidden(true) } }
}

enum ZelquorinApp: String, CaseIterable, Identifiable {
    case terminal = "Terminal", notes = "Notes", files = "Files", calculator = "Calculator", settings = "Settings", browser = "Browser", clock = "Clock", system = "System", sketch = "Sketch", store = "App Store", library = "Library", focus = "Focus Timer", converter = "Unit Converter", puzzle = "Tile Puzzle"
    var id: String { rawValue }
    var icon: String {
        switch self {
        case .terminal: return "terminal"
        case .notes: return "note.text"
        case .files: return "folder.fill"
        case .calculator: return "calculator"
        case .settings: return "gearshape.fill"
        case .browser: return "globe"
        case .clock: return "clock"
        case .system: return "cpu"
        case .sketch: return "pencil.tip.crop.circle"
        case .store: return "bag.fill"
        case .library: return "square.grid.3x3.fill"
        case .focus: return "timer"
        case .converter: return "arrow.left.arrow.right"
        case .puzzle: return "square.grid.3x3"
        }
    }
    var module: WorkspaceModule? { WorkspaceModule(rawValue: rawValue) }
}

struct ZelquorinWindow: Identifiable {
    let id = UUID()
    let app: ZelquorinApp
    var rect: CGRect
    var order: Double
    var minimized = false
    var maximized = false
}

struct Desktop: View {
    @AppStorage("zelquorin.accent") private var accentName = "Cyan"
    @AppStorage("zelquorin.wallpaper") private var wallpaper = "Orbit"
    @AppStorage("zelquorin.animations") private var animations = true
    @AppStorage("zelquorin.grid") private var grid = true
    @AppStorage("zelquorin.widgets") private var desktopIcons = true
    @AppStorage("zelquorin.dock") private var pinnedApps = true
    @AppStorage("zelquorin.store.modules") private var modules = ""
    @AppStorage("zelquorin.taskbar.pins") private var pins = "Browser|Files|Notes|App Store|Settings"
    @AppStorage("zelquorin.ambient.enabled") private var ambientEnabled = true
    @AppStorage("zelquorin.ambient.volume") private var ambientVolume = 0.22
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.scenePhase) private var scenePhase
    @StateObject private var ambience = DesktopAmbience()
    @State private var windows: [ZelquorinWindow] = []
    @State private var launcher = false
    @State private var control = false
    @State private var search = ""
    @State private var boot = true
    @State private var locked = true
    @AppStorage("zelquorin.login.onReturn") private var lockOnReturn = true
    @AppStorage("zelquorin.window.motion") private var motionDuration = 0.22
    @AppStorage("zelquorin.taskbar.date") private var showDate = true
    @AppStorage("zelquorin.taskbar.battery") private var showBattery = true
    @AppStorage("zelquorin.taskbar.clock24") private var clock24 = false
    @AppStorage("zelquorin.desktop.iconSize") private var iconSize = 50.0
    @AppStorage("zelquorin.desktop.gridOpacity") private var gridOpacity = 0.035
    @AppStorage("zelquorin.window.large") private var largeWindows = false
    @State private var closing = false
    @State private var asleep = false
    @State private var wasBackgrounded = false
    @State private var topOrder: Double = 0
    @State private var battery: Float = -1
    @State private var batteryState: UIDevice.BatteryState = .unknown
    private var accent: Color { switch accentName { case "Violet": return .purple; case "Emerald": return .mint; case "Amber": return .orange; default: return .cyan } }
    private var motion: Animation? { animations && !reduceMotion ? .easeInOut(duration: motionDuration) : nil }
    private var availableApps: [ZelquorinApp] { ZelquorinApp.allCases.filter { app in app.module == nil || modules.split(separator: "|").contains { String($0) == app.rawValue } } }
    private var taskbarApps: [ZelquorinApp] { availableApps.filter { app in (pinnedApps && pins.split(separator: "|").contains { String($0) == app.rawValue }) || windows.contains { $0.app == app } } }
    private var audioActive: Bool { scenePhase == .active && !boot && !closing && !asleep && !locked && ambientEnabled }
    var body: some View {
        ZStack {
            background.ignoresSafeArea()
            VStack(spacing: 0) {
                GeometryReader { geo in workspace(geo.size) }
                GeometryReader { geo in
                    taskbar(CGSize(width: geo.size.width, height: max(1, geo.frame(in: .named("desktop")).minY)))
                }.frame(height: 58)
            }.coordinateSpace(name: "desktop")
            if asleep {
                Color.black.ignoresSafeArea().overlay {
                    Button { asleep = false; locked = true; boot = true } label: { Image(systemName: "power").font(.system(size: 35, weight: .light)).foregroundStyle(.gray).padding(30) }.buttonStyle(.plain).accessibilityLabel("Start ZELQUORIN")
                }.zIndex(10000)
            }
            if locked && !asleep && !boot && !closing {
                WorkspaceLogin { locked = false }.zIndex(10000)
            }
            if boot || closing {
                BootAnimation(closing: closing) {
                    if closing { asleep = true; closing = false; windows.removeAll(); topOrder = 0 }
                    else { boot = false }
                }.id(closing).zIndex(10001)
            }
        }.tint(accent)
        .onAppear { UIDevice.current.isBatteryMonitoringEnabled = true; updateBattery(); syncAudio() }
        .onReceive(NotificationCenter.default.publisher(for: UIDevice.batteryLevelDidChangeNotification)) { _ in updateBattery() }
        .onReceive(NotificationCenter.default.publisher(for: UIDevice.batteryStateDidChangeNotification)) { _ in updateBattery() }
        .onChange(of: audioActive) { _, _ in syncAudio() }
        .onChange(of: ambientVolume) { _, _ in syncAudio() }
        .onChange(of: modules) { _, _ in withAnimation(motion) { windows.removeAll { !availableApps.contains($0.app) } } }
        .onChange(of: scenePhase) { _, phase in
            if phase == .background { wasBackgrounded = true; boot = false; closing = false; launcher = false; control = false }
            if phase == .active { updateBattery(); if wasBackgrounded { wasBackgrounded = false; asleep = false; locked = lockOnReturn; boot = true } }
            syncAudio()
        }.onDisappear { ambience.stop() }
    }
    private func workspace(_ bounds: CGSize) -> some View {
        ZStack(alignment: .topLeading) {
            Color.clear
            if desktopIcons {
                ScrollView { LazyVGrid(columns: [GridItem(.adaptive(minimum: 84, maximum: 96))], alignment: .leading, spacing: 16) {
                    ForEach(availableApps) { app in appTile(app, bounds: bounds) }
                }.padding(12) }.frame(width: min(bounds.width, 220)).frame(maxHeight: .infinity, alignment: .top)
            }
            ForEach(windows) { win in windowView(win, bounds: bounds).zIndex(win.order) }
            if launcher || control {
                Color.black.opacity(0.001).contentShape(Rectangle()).onTapGesture { withAnimation(motion) { launcher = false; control = false } }.zIndex(9000)
                if launcher { launcherPanel(bounds).frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottomLeading).padding(8).transition(.move(edge: .bottom).combined(with: .opacity)).zIndex(9001) }
                if control { controlPanel.frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottomTrailing).padding(8).transition(.move(edge: .bottom).combined(with: .opacity)).zIndex(9001) }
            }
        }.frame(width: bounds.width, height: bounds.height).clipped().coordinateSpace(name: "windowWorkspace")
        .onChange(of: bounds) { _, newBounds in
            for index in windows.indices { windows[index].rect = WindowGeometry.fit(windows[index].rect, in: newBounds) }
        }
    }
    private func windowView(_ win: ZelquorinWindow, bounds: CGSize) -> some View {
        let rect = win.maximized ? CGRect(origin: .zero, size: bounds) : WindowGeometry.fit(win.rect, in: bounds)
        let active = windows.filter { !$0.minimized }.max { $0.order < $1.order }?.id == win.id
        return WindowFrame(window: win, rect: rect, bounds: bounds, active: active, accent: accent, update: { newRect in
            change(win.id) { $0.rect = WindowGeometry.fit(newRect, in: bounds) }
        }, focus: { focus(win.id) }, close: { withAnimation(motion) { windows.removeAll { $0.id == win.id } } }, minimize: { withAnimation(motion) { change(win.id) { $0.minimized = true } } }, maximize: { focus(win.id); withAnimation(motion) { change(win.id) { $0.maximized.toggle() } } }, openModule: { module in if let app = ZelquorinApp(rawValue: module.rawValue) { open(app, bounds: bounds) } })
            .position(x: rect.midX, y: rect.midY)
            .scaleEffect(win.minimized ? 0.12 : 1, anchor: .bottom)
            .offset(y: win.minimized ? bounds.height / 2 : 0)
            .opacity(win.minimized ? 0 : 1).allowsHitTesting(!win.minimized).accessibilityHidden(win.minimized)
            .transition(.scale(scale: 0.94).combined(with: .opacity))
    }
    private var background: some View {
        ZStack {
            Color(red: 0.025, green: 0.04, blue: 0.09)
            if wallpaper != "Black" { RadialGradient(colors: [accent.opacity(0.23), .clear], center: wallpaper == "Orbit" ? .bottomTrailing : .topLeading, startRadius: 20, endRadius: 850) }
            if wallpaper == "Orbit" { ForEach(0..<5) { i in Circle().stroke(accent.opacity(0.12),lineWidth: 1).frame(width: CGFloat(260+i*132)).offset(x: 330,y: 100) } }
            if grid { Canvas { ctx, size in var p = Path(); stride(from: CGFloat(0), through: size.width, by: 40).forEach { x in p.move(to: CGPoint(x:x,y:0)); p.addLine(to:CGPoint(x:x,y:size.height)) }; stride(from: CGFloat(0), through: size.height, by: 40).forEach { y in p.move(to:CGPoint(x:0,y:y)); p.addLine(to:CGPoint(x:size.width,y:y)) }; ctx.stroke(p,with:.color(.white.opacity(gridOpacity)),lineWidth:1) } }
        }
    }
    private func taskbar(_ bounds: CGSize) -> some View {
        HStack(spacing: 8) {
            Button { withAnimation(motion) { launcher.toggle(); control = false; search = "" } } label: { Image("ClosingLogo").resizable().scaledToFit().frame(width: 35, height: 35).frame(width: 52, height: 52).background(launcher ? accent.opacity(0.16) : .clear) }.buttonStyle(.plain).accessibilityLabel("Start menu")
            Divider().frame(height: 30)
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 4) { ForEach(taskbarApps) { app in
                    let win = windows.first { $0.app == app }
                    let active = win != nil && win?.minimized == false && windows.filter { !$0.minimized }.max { $0.order < $1.order }?.id == win?.id
                    Button {
                        if active, let win { withAnimation(motion) { change(win.id) { $0.minimized = true } } }
                        else { open(app, bounds: bounds) }
                    } label: {
                        VStack(spacing: 3) { Image(systemName: app.icon).font(.system(size: 21)).frame(height: 29); Capsule().fill(win == nil ? .clear : (active ? accent : Color.gray)).frame(width: active ? 24 : 10, height: 3) }.frame(width: 48, height: 48).background(active ? accent.opacity(0.12) : .clear)
                    }.buttonStyle(.plain).accessibilityLabel(app.rawValue).contextMenu { pinButton(app); if let win { Button("Close", role: .destructive) { withAnimation(motion) { windows.removeAll { $0.id == win.id } } } } }
                } }
            }.frame(maxWidth: .infinity)
            Divider().frame(height: 30)
            Button { withAnimation(motion) { control.toggle(); launcher = false } } label: { Image(systemName: "slider.horizontal.3").font(.system(size: 19)).frame(width: 35, height: 48).background(control ? accent.opacity(0.12) : .clear) }.buttonStyle(.plain).accessibilityLabel("Control center")
            if showBattery { Button { open(.system, bounds: bounds) } label: { HStack(spacing: 4) { Image(systemName: batteryState == .charging ? "battery.100percent.bolt" : "battery.100percent"); Text(battery < 0 ? "—" : "\(Int((battery*100).rounded()))%").monospacedDigit() }.font(.caption).frame(height: 48) }.buttonStyle(.plain).accessibilityLabel("Battery") }
            Button { open(.clock, bounds: bounds) } label: { TimelineView(.periodic(from: .now, by: 1)) { ctx in VStack(alignment: .trailing, spacing: 2) { Text(clock24 ? ctx.date.formatted(.dateTime.hour(.twoDigits(amPM: .omitted)).minute().locale(Locale(identifier: "en_GB"))) : ctx.date.formatted(date: .omitted, time: .shortened)).font(.callout.monospacedDigit()); if showDate { Text(ctx.date, format: .dateTime.month(.abbreviated).day().year()).font(.caption2).foregroundStyle(.secondary) } } }.frame(minWidth: 74, minHeight: 48) }.buttonStyle(.plain).accessibilityLabel("Clock and date")
        }.padding(.horizontal, 8).frame(height: 58).background(Color(red: 0.055, green: 0.065, blue: 0.085)).overlay(alignment: .top) { Rectangle().fill(.white.opacity(0.13)).frame(height: 1) }
    }
    private func appTile(_ app: ZelquorinApp, bounds: CGSize) -> some View {
        Button { open(app,bounds:bounds) } label: {
            VStack(spacing: 6) { Image(systemName: app.icon).font(.system(size: 27, weight: .light)).foregroundStyle(accent).frame(width: iconSize, height: iconSize).background(accent.opacity(0.08), in: RoundedRectangle(cornerRadius: 8)); Text(app.rawValue).font(.caption).foregroundStyle(.white).lineLimit(2).multilineTextAlignment(.center) }.frame(width: 84, height: 82)
        }.buttonStyle(DesktopPressStyle()).accessibilityLabel("Open \(app.rawValue)").contextMenu { pinButton(app) }
    }
    private func pinButton(_ app: ZelquorinApp) -> some View {
        let isPinned = pins.split(separator: "|").contains { String($0) == app.rawValue }
        return Button(isPinned ? "Unpin from taskbar" : "Pin to taskbar", systemImage: isPinned ? "pin.slash" : "pin") {
            var items = pins.split(separator: "|").map(String.init)
            if isPinned { items.removeAll { $0 == app.rawValue } } else { items.append(app.rawValue) }
            pins = items.joined(separator: "|")
        }
    }
    private func launcherPanel(_ bounds: CGSize) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack { Text("Apps").font(.title2.weight(.medium)); Spacer(); Button { launcher = false; locked = true } label: { Image(systemName: "lock.fill").padding(8) }.accessibilityLabel("Lock workspace"); Button { withAnimation(motion) { launcher = false; closing = true } } label: { Image(systemName: "power").padding(8) }.accessibilityLabel("Shut down") }
            TextField("Search apps", text: $search).textFieldStyle(.roundedBorder)
            ScrollView { LazyVGrid(columns: [GridItem(.adaptive(minimum: 88))], spacing: 8) { ForEach(availableApps.filter { search.isEmpty || $0.rawValue.localizedCaseInsensitiveContains(search) }) { app in appTile(app, bounds: bounds) } } }
        }.padding(16).frame(width: min(430,max(1,bounds.width-16)), height: min(420,max(1,bounds.height-16))).background(Color(red: 0.075, green: 0.09, blue: 0.12)).overlay(Rectangle().strokeBorder(.white.opacity(0.15))).shadow(radius: 12)
    }
    private var controlPanel: some View {
        ScrollView { VStack(alignment: .leading, spacing: 16) {
            Text("Control Center").font(.headline)
            Toggle("Animations", isOn: $animations); Toggle("Desktop grid", isOn: $grid); Toggle("Desktop icons", isOn: $desktopIcons); Toggle("Pinned apps", isOn: $pinnedApps)
            Toggle("Ambient sound", isOn: $ambientEnabled); Slider(value: $ambientVolume, in: 0...1).accessibilityLabel("Ambient volume").disabled(!ambientEnabled)
            Picker("Accent", selection: $accentName) { ForEach(["Cyan","Violet","Emerald","Amber"], id: \.self) { Text($0) } }
            Button { control = false; closing = true } label: { Label("Shut down", systemImage: "power") }.buttonStyle(.bordered)
        }.padding(18) }.frame(width: 310, height: 350).background(Color(red: 0.075, green: 0.09, blue: 0.12)).overlay(Rectangle().strokeBorder(.white.opacity(0.15)))
    }
    private func open(_ app: ZelquorinApp, bounds: CGSize) {
        guard availableApps.contains(app) else { return }
        withAnimation(motion) {
            launcher = false; control = false; search = ""
            if let win = windows.first(where: { $0.app == app }) { restore(win.id); return }
            topOrder += 1
            let n = CGFloat(windows.count % 4) * 22
            let w = min(largeWindows ? 1100 : 760, max(1, bounds.width - 24)), h = min(largeWindows ? 800 : 550, max(1,bounds.height - 24))
            let rect = WindowGeometry.fit(CGRect(x: (bounds.width-w)/2+n, y: (bounds.height-h)/2+n, width: w, height: h), in: bounds)
            windows.append(ZelquorinWindow(app: app, rect: rect, order: topOrder))
        }
    }
    private func change(_ id: UUID, _ fn: (inout ZelquorinWindow) -> Void) { if let i = windows.firstIndex(where: { $0.id == id }) { fn(&windows[i]) } }
    private func focus(_ id: UUID) { guard let current = windows.first(where: { $0.id == id }), current.order != topOrder else { return }; topOrder += 1; change(id) { $0.order = topOrder } }
    private func restore(_ id: UUID) { change(id) { $0.minimized = false }; focus(id) }
    private func updateBattery() { battery = UIDevice.current.batteryLevel; batteryState = UIDevice.current.batteryState }
    private func syncAudio() { if audioActive { ambience.play(volume: Float(ambientVolume)) } else { ambience.stop() } }
}

struct DesktopPressStyle: ButtonStyle {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @AppStorage("zelquorin.animations") private var animations = true
    func makeBody(configuration: Configuration) -> some View { configuration.label.scaleEffect(configuration.isPressed && animations && !reduceMotion ? 0.94 : 1).opacity(configuration.isPressed ? 0.75 : 1).animation(animations && !reduceMotion ? .easeOut(duration: 0.12) : nil, value: configuration.isPressed) }
}

struct WindowFrame: View {
    let window: ZelquorinWindow; let rect: CGRect; let bounds: CGSize; let active: Bool; let accent: Color
    let update: (CGRect) -> Void; let focus: () -> Void; let close: () -> Void; let minimize: () -> Void; let maximize: () -> Void; let openModule: (WorkspaceModule) -> Void
    @State private var dragStart: CGRect?
    @State private var resizeStart: CGRect?
    @GestureState private var dragging = false
    @GestureState private var resizing = false
    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 0) {
                HStack(spacing: 9) { Image(systemName: window.app.icon).foregroundStyle(active ? accent : .secondary); Text(window.app.rawValue).font(.system(size: 15, weight: .medium)); Spacer(minLength: 0) }.padding(.leading, 12).frame(maxWidth: .infinity, maxHeight: .infinity).contentShape(Rectangle())
                    .onTapGesture(count: 2, perform: maximize).onTapGesture(perform: focus)
                    .gesture(DragGesture(minimumDistance: 2, coordinateSpace: .named("windowWorkspace")).updating($dragging) { _, state, _ in state = true }.onChanged { value in
                        guard !window.maximized else { return }
                        if dragStart == nil { dragStart = rect; focus() }
                        if let start = dragStart { update(WindowGeometry.moved(start, by: value.translation)) }
                    }.onEnded { value in if let start = dragStart { update(WindowGeometry.moved(start, by: value.translation)) }; dragStart = nil })
                titleButton("minus", label: "Minimize", action: minimize)
                titleButton(window.maximized ? "rectangle.on.rectangle" : "square", label: "Toggle maximize", action: maximize)
                titleButton("xmark", label: "Close", action: close)
            }.frame(height: 42).background(active ? Color(red: 0.13, green: 0.16, blue: 0.20) : Color(red: 0.095, green: 0.105, blue: 0.13))
            Divider()
            content.frame(maxWidth: .infinity, maxHeight: .infinity).clipped()
            if !window.maximized {
                HStack { Spacer(); Image(systemName: "arrow.down.right").font(.caption).frame(width: 40, height: 30).contentShape(Rectangle()).gesture(DragGesture(minimumDistance: 2, coordinateSpace: .named("windowWorkspace")).updating($resizing) { _, state, _ in state = true }.onChanged { value in
                    if resizeStart == nil { resizeStart = rect; focus() }
                    if let start = resizeStart { update(WindowGeometry.resized(start, by: value.translation, in: bounds)) }
                }.onEnded { value in if let start = resizeStart { update(WindowGeometry.resized(start, by: value.translation, in: bounds)) }; resizeStart = nil }).accessibilityLabel("Resize window") }.frame(height: 30).background(.white.opacity(0.025))
            }
        }.frame(width: max(1, rect.width), height: max(1, rect.height)).background(Color(red: 0.055, green: 0.067, blue: 0.095)).clipShape(Rectangle()).overlay(Rectangle().strokeBorder(active ? accent.opacity(0.62) : Color.white.opacity(0.15), lineWidth: 1)).shadow(color: .black.opacity(0.42), radius: active ? 12 : 6, y: 5).simultaneousGesture(TapGesture().onEnded { focus() })
        .onChange(of: dragging) { _, value in if !value { dragStart = nil } }
        .onChange(of: resizing) { _, value in if !value { resizeStart = nil } }
    }
    private func titleButton(_ icon: String, label: String, action: @escaping () -> Void) -> some View { Button(action: action) { Image(systemName: icon).font(.system(size: 14, weight: .medium)).frame(width: 46, height: 42).contentShape(Rectangle()) }.buttonStyle(DesktopPressStyle()).accessibilityLabel(label) }
    @ViewBuilder var content: some View {
        switch window.app { case .terminal: TerminalApp(); case .notes: NotesApp(); case .files: FilesApp(); case .calculator: CalculatorApp(); case .settings: SettingsApp(); case .browser: BrowserApp(); case .clock: ClockApp(); case .system: SystemApp(); case .sketch: SketchApp(); case .store: ZelquorinStoreView(); case .library: ZelquorinLibraryView(openModule: openModule); case .focus: FocusModule(); case .converter: ConverterModule(); case .puzzle: PuzzleModule() }
    }
}
