# Build identification update 0.3.2

The app display name is ZELQUORIN 0.3.2, Settings displays the real bundle version and build, and the IPA is versioned. Bundle identifier remains unchanged for updates. This update preserves the 0.3.1 desktop and features.

# ZELQUORIN OS — iPad Edition 0.3
Native SwiftUI workspace for iPadOS 17+. Bundle identifier remains `com.zelquorin.workspace.tablet`. Preserve the same signing identity and provisioning when upgrading; export important files before installing. This is an application, not a replacement operating system.

## Version 0.3
- Removes the top header, Workspace 01 banner and large desktop clock. A full-width bottom taskbar holds a Start menu, running and pinned apps, control center, live battery percentage, clock and date. Long-press apps to pin/unpin; tap the active taskbar app to minimize; tap the clock or battery to open their apps.
- Square desktop window frames with separate titlebar controls, drag only from the titlebar, stable workspace coordinates, constrained resizing, stable window identity/z-order and double-tap titlebar to maximize/restore. Open, close, restore, minimize and maximize animations; respects Reduce Motion.
- Original quiet 24-second ambient loop, enabled by default at 22% volume. Sound settings provide an independent toggle and slider. Plays only while the workspace is active, not during the startup, shutdown or backgrounding. The ambient audio session respects iPad silent mode and audio interruptions.
- Keeps the approved 10-second startup and closing sequences and their sounds. Shutdown clears windows after the animation and shows a black power screen. iPadOS does not permit normal apps to return themselves to the Home Screen or reliably quit automatically; use the system Home gesture. Tap the power button to restart.
- Apple catalog shows icons and favorites. Apple controls installation and launching; Apple apps cannot be embedded. Optional ZELQUORIN Store modules (Focus Timer, Unit Converter, Tile Puzzle) now open in independent desktop windows, appear on the desktop and in Start, and can be pinned. Removing a module closes its window. The existing catalog age filter is retained; no device restrictions are bypassed.
- Removes redundant explanatory system banners and disclaimers from the desktop, System monitor, browser, store and settings, while keeping actual errors and destructive-action confirmations.
- Retains Notes, Files, Calculator, Clock, Sketch, System, Settings, Browser (tabs/bookmarks/history/downloads), Store and Library. New Black wallpaper option. Existing stored settings/data keys are retained.

## Upgrade your existing ZIP-based GitHub repository
1. Upload `ZELQUORIN-OS-iPad-Edition-0.3.zip` to the root of your repository.
2. Edit `.github/workflows/build.yml` and change the unzip filename from `ZELQUORIN-OS-iPad-Edition-0.2.zip` to `ZELQUORIN-OS-iPad-Edition-0.3.zip`. Keep the other steps as before. Commit the change.
3. Open Actions and select the run for the workflow edit (uploading alone may trigger a build of 0.2).
4. Download the unsigned IPA artifact if successful. Use authorized Apple signing and provisioning. Retain your data by backing it up and keeping the same signing identity/bundle ID where supported.

## Device verification checklist
- Launch, wait 10 seconds, listen for ambience; check its settings and volume. Verify it stops for shutdown and backgrounding.
- Check bottom-right live clock, date, and battery. Tap each to open Clock/System.
- Move a window slowly and quickly by its titlebar. Resize by dragging its bottom-right handle, including at workspace edges. Try overlapping windows, changing focus, and rotation.
- Test open/close/minimize/restore/maximize, double-tap titlebar, taskbar pins and Reduce Motion.
- Install/remove a ZELQUORIN module, launch it from Start or Library, check that it runs in its own window.
- Check Apple catalog icons/favorites and official product pages; verify external apps stay external.
- Check the retained browser, downloads and saved local notes/files. Use the shutdown button to see the 10-second sequence and black power screen.

## Build on a Mac
1. Extract this ZIP. Open `ZELQUORIN.xcodeproj` using Xcode 16 or newer. Use a current Xcode release compatible with your iPadOS version.
2. Select the ZELQUORIN target > Signing & Capabilities. Choose an authorized Apple development team, and adjust the bundle identifier if necessary. Do not share credentials or signing keys.
3. Select an iPad simulator and click Run to check the interface. Then select your connected iPad for normal device deployment using Apple's supported signing and provisioning workflow.
4. For an IPA, use Xcode's Product > Archive and an available authorized development distribution option. Direct Xcode deployment is generally simpler.

## Build using GitHub Actions
Upload the **contents** of this project folder, including the hidden `.github/workflows/build.yml`, into your own repository. In Actions, select **Build ZELQUORIN for iPad** and run the workflow. If successful, download `ZELQUORIN-iPad-unsigned` from the run's artifacts. It contains an unsigned IPA requiring valid signing and provisioning. The included workflow has not been executed here; if it fails, inspect the build log. Normal device protections remain in force.

## Verification and limitations
Validated here: all Swift sources parse; 15 arithmetic tests and 10 geometry checks pass; all asset references resolve; startup/closing audio are 10 seconds each and ambience is 24 seconds. No iOS SDK/Xcode is available here, so native compilation, interaction smoothness, audio playback and actual device installation must be verified with GitHub Actions and physical iPad testing. This ZIP contains source, not a compiled IPA.

## 0.4.0 (build 6)
- Adds a workspace login after startup, a customizable profile name, optional Apple device-owner authentication and a lock action. This is a workspace gate, not a separate iPadOS account or independent data encryption.
- Adds functional desktop, taskbar, window, login, browser, file and terminal preferences.
- Files now includes a navigation sidebar, folders, back/forward/up, sorting, search, copy/cut/paste, renaming, properties, import/export, Quick Look and text editing. Earlier downloads stay where they were; new browser downloads go to Downloads.
- JavaScript files can be opened in Terminal, reviewed and run explicitly. The embedded JavaScriptCore interpreter has no shell, network or native bridge apart from console output. Run only trusted scripts; a runaway script may require restarting the app. Other source languages are editable but not executable in this release. Native IPA, EXE and DMG execution and ZIP extraction are not implemented.
- Browser uses WKWebView, HTTPS navigation, desktop/mobile preferences, actual website requests, inline media support, popup handling and attachment downloads. Website sign-in, DRM and playback are subject to individual website and WebKit restrictions. No live-site testing was performed in the development environment.
- Existing bundle ID and logo/audio assets remain unchanged. Local arithmetic and geometry tests and Swift syntax parsing pass; Xcode SDK type checking, compilation, signing and physical device verification are pending.
