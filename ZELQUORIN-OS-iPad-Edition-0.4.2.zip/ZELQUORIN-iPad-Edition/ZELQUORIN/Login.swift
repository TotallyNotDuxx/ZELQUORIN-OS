import SwiftUI
import UIKit
import LocalAuthentication
import Security
import CommonCrypto
import PhotosUI
import ImageIO

// App-local workspace lock, independent of the iPad passcode.
enum LockKind: String, CaseIterable, Codable { case pattern = "Dot pattern", pin = "4–8 digit PIN", custom = "Custom-length PIN", password = "Password"
    func valid(_ value: String) -> Bool {
        let digits = !value.isEmpty && value.utf8.allSatisfy { (48...57).contains($0) }
        switch self {
        case .pattern: return (4...9).contains(value.count) && Set(value).count == value.count && value.allSatisfy { "123456789".contains($0) }
        case .pin: return digits && (4...8).contains(value.count)
        case .custom: return digits && (4...64).contains(value.count)
        case .password: return (4...128).contains(value.count) && value.utf8.count <= 512
        }
    }
    var hint: String { switch self { case .pattern: return "Connect at least four dots."; case .pin: return "Enter 4–8 digits."; case .custom: return "Enter 4–64 digits."; case .password: return "Enter 4–128 characters." } }
}
struct LockRecord: Codable { let kind: LockKind; let salt: Data; let hash: Data }
enum WorkspaceLock {
    static let key: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: "com.zelquorin.workspace.lock", kSecAttrAccount as String: "credential"]
    static func read() throws -> LockRecord? {
        var query = key; query[kSecReturnData as String] = true; query[kSecMatchLimit as String] = kSecMatchLimitOne
        var item: CFTypeRef?; let status = SecItemCopyMatching(query as CFDictionary, &item)
        if status == errSecItemNotFound { return nil }
        guard status == errSecSuccess, let data = item as? Data else { throw NSError(domain: NSOSStatusErrorDomain, code: Int(status)) }
        return try JSONDecoder().decode(LockRecord.self, from: data)
    }
    static func derive(_ value: String, salt: Data) throws -> Data {
        let password = Array(value.utf8); var output = Data(count: 32)
        let status = output.withUnsafeMutableBytes { dst in salt.withUnsafeBytes { src in password.withUnsafeBytes { pwd in
            CCKeyDerivationPBKDF(CCPBKDFAlgorithm(kCCPBKDF2), pwd.bindMemory(to: Int8.self).baseAddress, password.count, src.bindMemory(to: UInt8.self).baseAddress, salt.count, CCPseudoRandomAlgorithm(kCCPRFHmacAlgSHA256), 210_000, dst.bindMemory(to: UInt8.self).baseAddress, 32)
        } } }
        guard status == kCCSuccess else { throw NSError(domain: "WorkspaceLock", code: Int(status)) }; return output
    }
    static func verify(_ value: String, _ record: LockRecord) throws -> Bool {
        guard record.kind.valid(value) else { return false }
        let test = try derive(value, salt: record.salt)
        guard test.count == record.hash.count else { return false }
        return zip(test, record.hash).reduce(UInt8(0)) { $0 | ($1.0 ^ $1.1) } == 0
    }
    static func save(_ value: String, kind: LockKind) throws {
        guard kind.valid(value) else { throw CocoaError(.fileWriteUnknown) }
        var salt = Data(count: 16); let result = salt.withUnsafeMutableBytes { SecRandomCopyBytes(kSecRandomDefault, 16, $0.baseAddress!) }
        guard result == errSecSuccess else { throw NSError(domain: NSOSStatusErrorDomain, code: Int(result)) }
        let data = try JSONEncoder().encode(LockRecord(kind: kind, salt: salt, hash: derive(value, salt: salt)))
        let attrs: [String: Any] = [kSecValueData as String: data, kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlockedThisDeviceOnly]
        var status = SecItemUpdate(key as CFDictionary, attrs as CFDictionary)
        if status == errSecItemNotFound { var query = key; attrs.forEach { query[$0.key] = $0.value }; status = SecItemAdd(query as CFDictionary, nil) }
        guard status == errSecSuccess else { throw NSError(domain: NSOSStatusErrorDomain, code: Int(status)) }
    }
    static func remove() throws { let status = SecItemDelete(key as CFDictionary); guard status == errSecSuccess || status == errSecItemNotFound else { throw NSError(domain: NSOSStatusErrorDomain, code: Int(status)) } }
}
struct PatternPad: View {
    @Binding var value: String
    @State private var finger: CGPoint?
    private func center(_ index: Int, _ size: CGSize) -> CGPoint { CGPoint(x: size.width * (CGFloat(index % 3) + 0.5) / 3, y: size.height * (CGFloat(index / 3) + 0.5) / 3) }
    var body: some View {
        VStack(spacing: 6) {
            GeometryReader { geo in
                let points = (0..<9).map { center($0, geo.size) }
                ZStack {
                    Path { path in
                        let selected = value.compactMap { Int(String($0)).map { $0 - 1 } }.filter { (0..<9).contains($0) }
                        if let first = selected.first { path.move(to: points[first]); for index in selected.dropFirst() { path.addLine(to: points[index]) }; if let finger { path.addLine(to: finger) } }
                    }.stroke(Color.accentColor, style: StrokeStyle(lineWidth: 3, lineCap: .round, lineJoin: .round)).allowsHitTesting(false)
                    ForEach(0..<9) { index in
                        Circle().fill(value.contains(String(index + 1)) ? Color.accentColor : Color.gray.opacity(0.6)).frame(width: 19, height: 19).overlay(Circle().stroke(.white.opacity(0.5), lineWidth: 1)).position(points[index])
                    }
                }.contentShape(Rectangle()).highPriorityGesture(DragGesture(minimumDistance: 0).onChanged { gesture in
                    if finger == nil { value = "" }; finger = gesture.location
                    if let index = points.firstIndex(where: { hypot($0.x - gesture.location.x, $0.y - gesture.location.y) < 28 }) { let digit = String(index + 1); if !value.contains(digit) { value.append(digit) } }
                }.onEnded { _ in finger = nil })
            }.frame(width: 205, height: 205).accessibilityLabel("Draw a pattern")
            HStack { Text("\(value.count) dots").font(.caption); Button("Clear") { value = "" }.buttonStyle(.borderless) }
        }
    }
}
struct CredentialInput: View {
    let kind: LockKind; let title: String; @Binding var value: String
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(.caption).foregroundStyle(.secondary)
            if kind == .pattern { PatternPad(value: $value).frame(maxWidth: .infinity) }
            else { SecureField(title, text: $value).textFieldStyle(.roundedBorder).keyboardType(kind == .password ? .default : .numberPad).textContentType(.none).textInputAutocapitalization(.never).autocorrectionDisabled() }
        }
    }
}
struct ChoiceRows: View {
    let title: String; let choices: [String]; @Binding var selection: String
    @State private var expanded = false
    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            Button { expanded.toggle() } label: { HStack { Text(title); Spacer(); Text(selection).foregroundStyle(.secondary); Image(systemName: expanded ? "chevron.up" : "chevron.down").font(.caption) }.contentShape(Rectangle()) }.buttonStyle(.plain)
            if expanded { ForEach(choices, id: \.self) { choice in Button { selection = choice; expanded = false } label: { HStack { Text(choice); Spacer(); if selection == choice { Image(systemName: "checkmark").foregroundStyle(Color.accentColor) } }.padding(9).frame(maxWidth: .infinity, alignment: .leading).background(.white.opacity(0.05)).contentShape(Rectangle()) }.buttonStyle(.plain) } }
        }.padding(.vertical, 3)
    }
}
struct LockSettings: View {
    @AppStorage("zelquorin.login.auth") private var deviceAuth = false
    @State private var record: LockRecord?
    @State private var loaded = false
    @State private var mode = LockKind.pin.rawValue
    @State private var previous = ""; @State private var first = ""; @State private var confirm = ""
    @State private var editing = false; @State private var message = ""
    private var kind: LockKind { LockKind(rawValue: mode) ?? .pin }
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            if loaded {
                LabeledContent("Workspace lock", value: record?.kind.rawValue ?? "Not set")
                Button(editing ? "Cancel" : (record == nil ? "Set workspace passcode" : "Change workspace passcode")) { editing.toggle(); previous = ""; first = ""; confirm = ""; message = "" }.buttonStyle(.bordered)
                if editing {
                    if let record { CredentialInput(kind: record.kind, title: "Current credential", value: $previous) }
                    ChoiceRows(title: "Lock type", choices: LockKind.allCases.map(\.rawValue), selection: $mode)
                    Text(kind.hint).font(.caption).foregroundStyle(.secondary)
                    CredentialInput(kind: kind, title: "New credential", value: $first)
                    CredentialInput(kind: kind, title: "Confirm credential", value: $confirm)
                    Button("Save workspace lock") { save() }.buttonStyle(.borderedProminent)
                    if record != nil { Button("Remove workspace lock", role: .destructive) { remove() }.buttonStyle(.bordered) }
                }
                Toggle(record == nil ? "Require device authentication" : "Allow Face ID as alternative", isOn: $deviceAuth)
            }
            if !message.isEmpty { Text(message).font(.caption).foregroundStyle(.secondary) }
        }.onAppear { reload() }.onChange(of: mode) { _,_ in first = ""; confirm = "" }
    }
    private func reload() { do { record = try WorkspaceLock.read(); loaded = true } catch { loaded = false; message = "Workspace credential unavailable." } }
    private func authorized() throws -> Bool { guard let record else { return true }; return try WorkspaceLock.verify(previous, record) }
    private func save() { do { guard try authorized() else { message = "Current credential is incorrect."; return }; guard kind.valid(first), first == confirm else { message = "Credentials must match and meet the length requirement."; return }; try WorkspaceLock.save(first, kind: kind); deviceAuth = false; finish() } catch { message = "Could not save workspace lock: \(error.localizedDescription)" } }
    private func remove() { do { guard try authorized() else { message = "Current credential is incorrect."; return }; try WorkspaceLock.remove(); finish() } catch { message = "Could not remove workspace lock." } }
    private func finish() { previous = ""; first = ""; confirm = ""; editing = false; message = "Saved."; reload() }
}

enum WorkspacePictures {
    static func url(_ name: String) -> URL { FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("ZelquorinPictures", isDirectory: true).appendingPathComponent(name + ".jpg") }
    static func load(_ name: String) -> UIImage? { UIImage(contentsOfFile: url(name).path) }
    static func save(_ data: Data, name: String) throws {
        guard let source = CGImageSourceCreateWithData(data as CFData, nil), let image = CGImageSourceCreateThumbnailAtIndex(source, 0, [kCGImageSourceCreateThumbnailFromImageAlways: true, kCGImageSourceCreateThumbnailWithTransform: true, kCGImageSourceThumbnailMaxPixelSize: name == "profile" ? 512 : 3000] as CFDictionary), let jpeg = UIImage(cgImage: image).jpegData(compressionQuality: 0.88) else { throw CocoaError(.fileReadCorruptFile) }
        let target = url(name); try FileManager.default.createDirectory(at: target.deletingLastPathComponent(), withIntermediateDirectories: true); try jpeg.write(to: target, options: .atomic)
    }
}
struct ProfileAvatar: View {
    @AppStorage("zelquorin.profile.revision") private var revision = 0
    @State private var photo: UIImage?
    var size: CGFloat = 80
    init(size: CGFloat = 80) { self.size = size }
    var body: some View { Group { if let photo { Image(uiImage: photo).resizable().scaledToFill().frame(width: size, height: size).clipShape(Circle()) } else { Image(systemName: "person.crop.circle.fill").font(.system(size: size, weight: .thin)).foregroundStyle(.gray) } }.onAppear { photo = WorkspacePictures.load("profile") }.onChange(of: revision) { _,_ in photo = WorkspacePictures.load("profile") } }
}
struct CustomWallpaper: View {
    @AppStorage("zelquorin.wallpaper.revision") private var revision = 0
    @State private var photo: UIImage?
    var body: some View { GeometryReader { geo in if let photo { Image(uiImage: photo).resizable().scaledToFill().frame(width: geo.size.width, height: geo.size.height).clipped() } else { Color.black } }.onAppear { photo = WorkspacePictures.load("wallpaper") }.onChange(of: revision) { _,_ in photo = WorkspacePictures.load("wallpaper") }.allowsHitTesting(false) }
}
struct PictureSettings: View {
    let name: String
    init(name: String) { self.name = name }
    @AppStorage("zelquorin.profile.revision") private var profileRevision = 0
    @AppStorage("zelquorin.wallpaper.revision") private var wallpaperRevision = 0
    @AppStorage("zelquorin.wallpaper") private var wallpaper = "Orbit"
    @State private var choice: PhotosPickerItem?
    @State private var errorMessage = ""
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            if name == "profile" { ProfileAvatar(size: 58) }
            PhotosPicker(selection: $choice, matching: .images) { Label(name == "profile" ? "Choose profile picture" : "Choose custom wallpaper", systemImage: "photo") }.buttonStyle(.bordered)
            Button(name == "profile" ? "Remove profile picture" : "Remove custom wallpaper", role: .destructive) { try? FileManager.default.removeItem(at: WorkspacePictures.url(name)); changed(); if name == "wallpaper" { wallpaper = "Orbit" } }.buttonStyle(.borderless)
            if !errorMessage.isEmpty { Text(errorMessage).font(.caption).foregroundStyle(.secondary) }
        }.onChange(of: choice) { _, item in guard let item else { return }; Task { do { guard let data = try await item.loadTransferable(type: Data.self) else { throw CocoaError(.fileReadCorruptFile) }; try WorkspacePictures.save(data, name: name); changed(); if name == "wallpaper" { wallpaper = "Custom" }; errorMessage = "" } catch { self.errorMessage = "Could not import image." }; choice = nil } }
    }
    private func changed() { if name == "profile" { profileRevision += 1 } else { wallpaperRevision += 1 } }
}

struct WorkspaceLogin: View {
    @AppStorage("zelquorin.login.name") private var profile = "User"
    @AppStorage("zelquorin.login.auth") private var requireAuth = false
    @AppStorage("zelquorin.login.retryAfter") private var retryAfter = 0.0
    @AppStorage("zelquorin.login.failures") private var failures = 0
    @State private var record: LockRecord?
    @State private var loaded = false
    @State private var value = ""
    @State private var errorMessage = ""
    @State private var busy = false
    let unlock: () -> Void
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            ScrollView { VStack(spacing: 16) {
                Image("StartupLogo").resizable().scaledToFit().frame(width: 230, height: 110)
                ProfileAvatar()
                Text(profile.isEmpty ? "User" : profile).font(.largeTitle.weight(.light))
                if loaded {
                    if let record { CredentialInput(kind: record.kind, title: record.kind.rawValue, value: $value).frame(maxWidth: 320); Button("Unlock") { signIn() }.buttonStyle(.borderedProminent).disabled(busy); if requireAuth { Button("Use Face ID", action: biometric).buttonStyle(.bordered).disabled(busy) } }
                    else { Button("Sign in", action: signIn).buttonStyle(.borderedProminent).disabled(busy) }
                } else { Button("Retry", action: load).buttonStyle(.bordered) }
                if !errorMessage.isEmpty { Text(errorMessage).font(.caption).foregroundStyle(.secondary) }
            }.frame(maxWidth: .infinity).padding(25) }.defaultScrollAnchor(.center)
        }.preferredColorScheme(.dark).onAppear(perform: load)
    }
    private func load() { do { record = try WorkspaceLock.read(); loaded = true; errorMessage = "" } catch { loaded = false; self.errorMessage = "Workspace credential unavailable. Try again." } }
    private func signIn() {
        guard loaded else { return }
        if let record {
            let delay = retryAfter - Date().timeIntervalSince1970
            guard delay <= 0 else { errorMessage = "Try again in \(Int(ceil(delay))) seconds."; return }
            do { if try WorkspaceLock.verify(value, record) { finish() } else { failures += 1; if failures >= 5 { retryAfter = Date().timeIntervalSince1970 + min(300, Double(failures - 4) * 15) }; value = ""; errorMessage = "Incorrect workspace credential." } } catch { self.errorMessage = "Could not verify workspace credential." }
        } else if requireAuth { authenticate(.deviceOwnerAuthentication) } else { finish() }
    }
    private func biometric() { authenticate(.deviceOwnerAuthenticationWithBiometrics) }
    private func authenticate(_ policy: LAPolicy) {
        let context = LAContext(); var reason: NSError?
        guard context.canEvaluatePolicy(policy, error: &reason) else { errorMessage = reason?.localizedDescription ?? "Authentication unavailable"; return }
        busy = true
        context.evaluatePolicy(policy, localizedReason: "Unlock ZELQUORIN") { success, failure in DispatchQueue.main.async { busy = false; if success { finish() } else { errorMessage = failure?.localizedDescription ?? "Authentication failed" } } }
    }
    private func finish() { value = ""; failures = 0; retryAfter = 0; unlock() }
}
