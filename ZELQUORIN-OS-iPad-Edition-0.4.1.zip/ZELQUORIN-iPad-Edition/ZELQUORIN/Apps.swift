import SwiftUI
import UIKit
import UniformTypeIdentifiers
import SafariServices
import PencilKit

struct NotesApp: View {
    @AppStorage("zelquorin.notes") private var saved = "[]"
    @State private var selected: UUID?
    struct Note: Codable, Identifiable { var id = UUID(); var title = "Untitled"; var body = "" }
    private var notes: [Note] { (try? JSONDecoder().decode([Note].self, from: Data(saved.utf8))) ?? [] }
    private func write(_ items: [Note]) { if let data = try? JSONEncoder().encode(items), let string = String(data:data,encoding:.utf8) { saved=string } }
    private func update(_ id:UUID, _ edit:(inout Note)->Void) { var list=notes; if let i=list.firstIndex(where:{$0.id==id}) { edit(&list[i]); write(list) } }
    var body: some View {
        HStack(spacing:0) {
            VStack(alignment:.leading) {
                Button { var list=notes; let note=Note(); list.append(note); write(list); selected=note.id } label: { Label("New note",systemImage:"plus") }.buttonStyle(.borderedProminent)
                ScrollView { VStack(alignment:.leading,spacing:8) { ForEach(notes) { note in HStack { Button { selected=note.id } label: { Text(note.title.isEmpty ? "Untitled":note.title).lineLimit(1).frame(maxWidth:.infinity,alignment:.leading) }.buttonStyle(.plain); Button(role:.destructive) { write(notes.filter{$0.id != note.id}); if selected==note.id {selected=nil} } label: { Image(systemName:"trash") }.accessibilityLabel("Delete \(note.title)") }.padding(8).background(selected==note.id ? Color.accentColor.opacity(0.18):.clear,in:RoundedRectangle(cornerRadius:8)) } } }
            }.padding(12).frame(width:155)
            Divider()
            if let id=selected, let note=notes.first(where:{$0.id==id}) {
                VStack(alignment:.leading) { TextField("Title",text:Binding(get:{notes.first(where:{$0.id==id})?.title ?? ""},set:{v in update(id){$0.title=v}})).font(.title2.bold()); Divider(); TextEditor(text:Binding(get:{notes.first(where:{$0.id==id})?.body ?? ""},set:{v in update(id){$0.body=v}})).scrollContentBackground(.hidden); ShareLink(item:note.title+"\n\n"+note.body){Label("Share note",systemImage:"square.and.arrow.up")} }.padding(14)
            } else { ContentUnavailableView("Select a note",systemImage:"note.text",description:Text("Create a note to get started.")) }
        }
    }
}

struct CalculatorApp: View {
    @State private var expression=""
    @State private var result="0"
    private let keys=["7","8","9","÷","4","5","6","×","1","2","3","−","0",".","=","+","(",")","⌫","AC"]
    var body:some View { ScrollView { VStack(alignment:.trailing,spacing:10){ Text(expression.isEmpty ? "0":expression).font(.title3.monospaced()).foregroundStyle(.secondary).lineLimit(2); Text(result).font(.system(size:38,weight:.light,design:.monospaced)).lineLimit(1).minimumScaleFactor(0.5); LazyVGrid(columns:Array(repeating:GridItem(.flexible()),count:4),spacing:8){ForEach(keys,id:\.self){ key in Button { press(key) } label:{Text(key).font(.title2.monospaced()).frame(maxWidth:.infinity).padding(.vertical,9).background(.white.opacity(0.07),in:RoundedRectangle(cornerRadius:10))}.buttonStyle(.plain)}} }.padding(15) } }
    private func press(_ key:String){ switch key {case "AC":expression="";result="0";case "⌫":if !expression.isEmpty {expression.removeLast()};case "=":do {let n=try Arithmetic.evaluate(expression);result=String(format:"%.12g",n)}catch{result="Invalid expression"};default:if expression.count<160 {expression+=key} } }
}

struct SettingsApp: View {
    @AppStorage("zelquorin.accent") private var accent = "Cyan"
    @AppStorage("zelquorin.wallpaper") private var wallpaper = "Orbit"
    @AppStorage("zelquorin.animations") private var animations = true
    @AppStorage("zelquorin.grid") private var grid = true
    @AppStorage("zelquorin.widgets") private var icons = true
    @AppStorage("zelquorin.dock") private var pinned = true
    @AppStorage("zelquorin.boot.sound") private var startupSound = true
    @AppStorage("zelquorin.close.sound") private var closingSound = true
    @AppStorage("zelquorin.ambient.enabled") private var ambient = true
    @AppStorage("zelquorin.ambient.volume") private var volume = 0.22
    @AppStorage("zelquorin.taskbar.pins") private var pins = "Browser|Files|Notes|App Store|Settings"
    @AppStorage("zelquorin.login.name") private var profile = "User"
    @AppStorage("zelquorin.login.auth") private var deviceAuth = false
    @AppStorage("zelquorin.login.onReturn") private var lockOnReturn = true
    @AppStorage("zelquorin.window.motion") private var motionDuration = 0.22
    @AppStorage("zelquorin.taskbar.date") private var showDate = true
    @AppStorage("zelquorin.taskbar.battery") private var showBattery = true
    @AppStorage("zelquorin.taskbar.clock24") private var clock24 = false
    @AppStorage("zelquorin.desktop.iconSize") private var iconSize = 50.0
    @AppStorage("zelquorin.desktop.gridOpacity") private var gridOpacity = 0.035
    @AppStorage("zelquorin.window.large") private var largeWindows = false
    @AppStorage("zelquorin.browser.search") private var engine = "Google"
    @AppStorage("zelquorin.browser.profile") private var browserProfile = "ZELQUORIN"
    @AppStorage("zelquorin.browser.desktop") private var desktopMode = true
    @AppStorage("zelquorin.browser.home") private var homepage = "https://www.google.com"
    @AppStorage("zelquorin.files.sort") private var fileSort = "Name"
    @AppStorage("zelquorin.files.hidden") private var hidden = false
    @AppStorage("zelquorin.terminal.font") private var terminalFont = 14.0
    @AppStorage("zelquorin.terminal.wrap") private var terminalWrap = true
    @State private var search = ""
    private func matches(_ string: String) -> Bool { search.isEmpty || string.localizedCaseInsensitiveContains(search) }
    var body: some View {
        Form {
            Section { TextField("Search settings", text: $search) }
            if matches("appearance accent color wallpaper grid animations") { Section("Appearance") {
                ChoiceRows(title: "Accent color", choices: ["Cyan","Violet","Emerald","Amber"], selection: $accent)
                ChoiceRows(title: "Wallpaper", choices: ["Orbit","Aurora","Black","Custom"], selection: $wallpaper)
                PictureSettings(name: "wallpaper")
                Toggle("Desktop grid", isOn: $grid); Toggle("Interface animations", isOn: $animations)
                Slider(value: $gridOpacity, in: 0...0.15) { Text("Grid intensity") }
                Slider(value: $iconSize, in: 36...64, step: 2) { Text("Icon size") }
            } }
            if matches("desktop icons taskbar pins layout") { Section("Desktop and taskbar") { Toggle("Desktop icons", isOn: $icons); Toggle("Show pinned apps", isOn: $pinned); Toggle("Show date", isOn: $showDate); Toggle("Show battery", isOn: $showBattery); Toggle("24-hour clock", isOn: $clock24) } }
            if matches("windows animation duration size") { Section("Windows") { Toggle("Open larger windows", isOn: $largeWindows); Slider(value: $motionDuration, in: 0.1...0.6, step: 0.05) { Text("Animation duration") }; Text(String(format: "%.2f s", motionDuration)).monospacedDigit() } }
            if matches("account profile login lock security face id passcode") { Section("Login and security") { PictureSettings(name: "profile"); TextField("Account name", text: $profile).textFieldStyle(.roundedBorder); LockSettings(); Toggle("Lock on returning to app", isOn: $lockOnReturn) } }
            if matches("browser search homepage desktop web privacy") { Section("Browser") { ChoiceRows(title: "Browser preset", choices: BrowserProfiles.names, selection: $browserProfile); ChoiceRows(title: "Search engine", choices: BrowserProfiles.engines, selection: $engine); Toggle("Desktop websites by default", isOn: $desktopMode); TextField("Homepage (HTTPS)", text: $homepage).textInputAutocapitalization(.never).autocorrectionDisabled(); Button("Clear browser history") { UserDefaults.standard.removeObject(forKey: "zelquorin.browser.history"); NotificationCenter.default.post(name: .zelquorinClearHistory, object: nil) } } }
            if matches("files sorting hidden explorer") { Section("Files") { ChoiceRows(title: "Sort by", choices: ["Name","Date","Size","Type"], selection: $fileSort); Toggle("Show hidden files", isOn: $hidden) } }
            if matches("terminal developer coding font wrap") { Section("Terminal") { Slider(value: $terminalFont, in: 10...24, step: 1) { Text("Font size") }; Text("\(Int(terminalFont)) pt"); Toggle("Wrap output", isOn: $terminalWrap) } }
            if matches("audio startup shutdown sound ambient volume boot closing") { Section("Sound") {
                Toggle("Startup sound", isOn: $startupSound); Toggle("Shutdown sound", isOn: $closingSound)
                Toggle("Background ambience", isOn: $ambient)
                HStack { Image(systemName: "speaker.fill"); Slider(value: $volume, in: 0...1).accessibilityLabel("Ambient volume"); Text("\(Int(volume*100))%").monospacedDigit() }.disabled(!ambient)
            } }
            if matches("accessibility reduce motion") { Section("Accessibility") { Toggle("Reduce motion", isOn: Binding(get: { !animations }, set: { animations = !$0 })) } }
            if matches("general reset about device permissions privacy") { Section("General") {
                LabeledContent("Version", value: Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "Unknown")
                LabeledContent("Build", value: Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "Unknown")
                Button("Restore appearance defaults") { accent = "Cyan"; wallpaper = "Orbit"; animations = true; grid = true; icons = true; pinned = true; pins = "Browser|Files|Notes|App Store|Settings" }
                Link("iPad Settings", destination: URL(string: UIApplication.openSettingsURLString)!)
            } }
        }.scrollContentBackground(.hidden)
        .onChange(of: browserProfile) { _, name in engine = BrowserProfiles.engine(name); homepage = BrowserProfiles.home(name); desktopMode = BrowserProfiles.desktop(name) }
    }
}

struct ClockApp:View {
    @AppStorage("zelquorin.stopwatch.started") private var started:Double=0
    @AppStorage("zelquorin.stopwatch.elapsed") private var elapsed:Double=0
    var body:some View { TimelineView(.periodic(from:.now,by:0.1)){ctx in ScrollView { VStack(spacing:18){Text(ctx.date,style:.time).font(.system(size:44,weight:.thin,design:.monospaced));Text(ctx.date.formatted(date:.complete,time:.omitted)).foregroundStyle(.secondary);Divider();Text("STOPWATCH").font(.caption.monospaced());Text(duration(elapsed+(started>0 ? max(0,ctx.date.timeIntervalSince1970-started):0))).font(.system(size:38,weight:.light,design:.monospaced));HStack{Button(started>0 ? "Pause":"Start"){if started>0{elapsed+=max(0,Date().timeIntervalSince1970-started);started=0}else{started=Date().timeIntervalSince1970}}.buttonStyle(.borderedProminent);Button("Reset"){started=0;elapsed=0}.buttonStyle(.bordered)} }.padding(20).frame(maxWidth:.infinity) } } }
    private func duration(_ t:Double)->String {let s=Int(max(0,t));return String(format:"%02d:%02d:%02d.%01d",s/3600,(s/60)%60,s%60,Int(max(0,t)*10)%10)}
}

struct SystemApp:View {
    @State private var battery:Float = -1
    private var memory:String{ByteCountFormatter.string(fromByteCount:Int64(ProcessInfo.processInfo.physicalMemory),countStyle:.memory)}
    private var storage:String { if let url=FileManager.default.urls(for:.documentDirectory,in:.userDomainMask).first,let v=try? url.resourceValues(forKeys:[.volumeAvailableCapacityKey]),let n=v.volumeAvailableCapacity {return ByteCountFormatter.string(fromByteCount:Int64(n),countStyle:.file)};return "Unavailable" }
    var body:some View { ScrollView { VStack(alignment:.leading,spacing:16){Label("System monitor",systemImage:"cpu").font(.title.bold());metric("iPadOS",UIDevice.current.systemVersion);metric("Physical memory",memory);metric("Logical CPU cores","\(ProcessInfo.processInfo.processorCount)");metric("Available volume capacity",storage);metric("Battery",battery<0 ? "Unavailable":"\(Int(battery*100))%");metric("Low power mode",ProcessInfo.processInfo.isLowPowerModeEnabled ? "On":"Off") }.padding(18) }.onAppear{UIDevice.current.isBatteryMonitoringEnabled=true;battery=UIDevice.current.batteryLevel}.onReceive(NotificationCenter.default.publisher(for:UIDevice.batteryLevelDidChangeNotification)){_ in battery=UIDevice.current.batteryLevel} }
    private func metric(_ key:String,_ value:String)->some View{HStack{Text(key).foregroundStyle(.secondary);Spacer();Text(value).font(.body.monospaced())}.padding(10).background(.white.opacity(0.045),in:RoundedRectangle(cornerRadius:10))}
}

struct SketchApp:View {
    @State private var canvas=PKCanvasView()
    @State private var status=""
    private var url:URL{FileManager.default.urls(for:.documentDirectory,in:.userDomainMask)[0].appendingPathComponent("zelquorin-sketch.drawing")}
    var body:some View{VStack(spacing:8){HStack{Label("Sketchpad",systemImage:"pencil.tip");Spacer();Button("Save"){do{try canvas.drawing.dataRepresentation().write(to:url,options:.atomic);status="Saved"}catch{status=error.localizedDescription}};Button("Clear"){canvas.drawing=PKDrawing();status="Cleared (save to keep)"}}.padding(.horizontal,12);SketchCanvas(canvas:canvas).clipShape(RoundedRectangle(cornerRadius:10));Text(status).font(.caption)}.padding(10).onAppear{if let d=try? Data(contentsOf:url),let drawing=try? PKDrawing(data:d){canvas.drawing=drawing}}}
}
struct SketchCanvas:UIViewRepresentable{let canvas:PKCanvasView;func makeUIView(context:Context)->PKCanvasView{canvas.drawingPolicy = .anyInput;canvas.tool=PKInkingTool(.pen,color:.systemBlue,width:5);canvas.backgroundColor = .white;return canvas};func updateUIView(_ view:PKCanvasView,context:Context){} }
