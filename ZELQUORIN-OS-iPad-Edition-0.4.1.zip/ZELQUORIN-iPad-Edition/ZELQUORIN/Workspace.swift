import SwiftUI
import UIKit
import UniformTypeIdentifiers
import QuickLook
import LocalAuthentication
import JavaScriptCore

enum WorkspaceFiles {
    static var root: URL { FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("ZELQUORIN Files", isDirectory: true) }
    static var downloads: URL { root.appendingPathComponent("Downloads", isDirectory: true) }
    static var documents: URL { root.appendingPathComponent("Documents", isDirectory: true) }
    static func prepare() throws { for url in [root, downloads, documents] { try FileManager.default.createDirectory(at: url, withIntermediateDirectories: true) } }
    static func inside(_ url: URL) -> Bool { let base = root.resolvingSymlinksInPath().standardizedFileURL.path; let path = url.resolvingSymlinksInPath().standardizedFileURL.path; return path == base || path.hasPrefix(base + "/") }
    static func valid(_ name: String) -> Bool { !name.isEmpty && name != "." && name != ".." && !name.contains("/") && !name.contains("\0") }
    static func unique(_ name: String, in folder: URL) -> URL {
        let original = folder.appendingPathComponent(name); if !FileManager.default.fileExists(atPath: original.path) { return original }
        let ext = original.pathExtension; let stem = original.deletingPathExtension().lastPathComponent
        var n = 2; while true { let candidate = folder.appendingPathComponent(stem + " (\(n))" + (ext.isEmpty ? "" : "." + ext)); if !FileManager.default.fileExists(atPath: candidate.path) { return candidate }; n += 1 }
    }
    static func changed() { NotificationCenter.default.post(name: .zelquorinFilesChanged, object: nil) }
    static func directory(_ url: URL) -> Bool { (try? url.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) == true }
    static func text(_ url: URL) throws -> String { guard inside(url), !directory(url), (try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0) <= 1_000_000 else { throw CocoaError(.fileReadTooLarge) }; return try String(contentsOf: url, encoding: .utf8) }
}
struct FileChoice: Identifiable { let url: URL; var id: URL { url } }
struct FilesApp: View {
    @AppStorage("zelquorin.files.sort") private var sort = "Name"
    @AppStorage("zelquorin.files.hidden") private var hidden = false
    @State private var folder = WorkspaceFiles.root
    @State private var files: [URL] = []
    @State private var back: [URL] = []
    @State private var forward: [URL] = []
    @State private var query = ""
    @State private var selected: URL?
    @State private var clipboard: URL?
    @State private var cut = false
    @State private var importing = false
    @State private var error = ""
    @State private var action = ""
    @State private var name = ""
    @State private var askName = false
    @State private var askDelete = false
    @State private var preview: URL?
    @State private var editor: FileChoice?
    @State private var details: FileChoice?
    @State private var runner: FileChoice?
    @State private var listMode = true
    private var visible: [URL] { files.filter { query.isEmpty || $0.lastPathComponent.localizedCaseInsensitiveContains(query) }.sorted { a,b in
        if WorkspaceFiles.directory(a) != WorkspaceFiles.directory(b) { return WorkspaceFiles.directory(a) }
        let av = try? a.resourceValues(forKeys: [.fileSizeKey,.contentModificationDateKey]); let bv = try? b.resourceValues(forKeys: [.fileSizeKey,.contentModificationDateKey])
        switch sort { case "Date": if av?.contentModificationDate != bv?.contentModificationDate { return (av?.contentModificationDate ?? .distantPast) > (bv?.contentModificationDate ?? .distantPast) }; case "Size": if av?.fileSize != bv?.fileSize { return (av?.fileSize ?? 0) > (bv?.fileSize ?? 0) }; case "Type": if a.pathExtension != b.pathExtension { return a.pathExtension < b.pathExtension }; default: break }
        return a.lastPathComponent.localizedStandardCompare(b.lastPathComponent) == .orderedAscending
    } }
    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 12) {
                Button { if let url = back.popLast() { forward.append(folder); folder = url; refresh() } } label: { Image(systemName: "chevron.left") }.disabled(back.isEmpty)
                Button { if let url = forward.popLast() { back.append(folder); folder = url; refresh() } } label: { Image(systemName: "chevron.right") }.disabled(forward.isEmpty)
                Button { navigate(folder.deletingLastPathComponent()) } label: { Image(systemName: "arrow.up") }.disabled(folder == WorkspaceFiles.root)
                Text("This Workspace / " + folder.path.replacingOccurrences(of: WorkspaceFiles.root.path, with: "").split(separator: "/").joined(separator: " / ")).lineLimit(1).frame(maxWidth: .infinity, alignment: .leading)
                Button(action: refresh) { Image(systemName: "arrow.clockwise") }
            }.padding(10).background(.white.opacity(0.04))
            HStack {
                Menu { Button("Folder", systemImage: "folder.badge.plus") { prompt("New folder", "") }; Button("Text file", systemImage: "doc.badge.plus") { prompt("New file", "Untitled.txt") }; Button("JavaScript", systemImage: "terminal") { prompt("New file", "main.js") } } label: { Label("New", systemImage: "plus") }
                Button { importing = true } label: { Image(systemName: "square.and.arrow.down") }.accessibilityLabel("Import files")
                Button { if let url = selected { clipboard = url; cut = false } } label: { Image(systemName: "doc.on.doc") }.disabled(selected == nil).accessibilityLabel("Copy")
                Button { if let url = selected { clipboard = url; cut = true } } label: { Image(systemName: "scissors") }.disabled(selected == nil).accessibilityLabel("Cut")
                Button(action: paste) { Image(systemName: "clipboard") }.disabled(clipboard == nil).accessibilityLabel("Paste")
                Menu { Picker("Sort", selection: $sort) { ForEach(["Name","Date","Size","Type"],id: \.self) { Text($0) } }; Toggle("Details view", isOn: $listMode) } label: { Image(systemName: "line.3.horizontal.decrease") }
                TextField("Search", text: $query).textFieldStyle(.roundedBorder)
            }.padding(8)
            Divider()
            HStack(spacing: 0) {
                VStack(alignment: .leading, spacing: 16) {
                    place("Home", "house", WorkspaceFiles.root)
                    place("Downloads", "arrow.down.circle", WorkspaceFiles.downloads)
                    place("Documents", "folder", WorkspaceFiles.documents)
                    Spacer()
                }.padding(12).frame(width: 125, alignment: .leading).background(.white.opacity(0.035))
                Divider()
                ScrollView { if listMode { VStack(spacing: 1) { HStack { Text("Name"); Spacer(); Text("Size") }.font(.caption).foregroundStyle(.secondary).padding(8); ForEach(visible,id: \.self) { row($0) } } } else { LazyVGrid(columns: [GridItem(.adaptive(minimum: 100))]) { ForEach(visible,id: \.self) { url in VStack { Image(systemName: WorkspaceFiles.directory(url) ? "folder.fill" : "doc").font(.largeTitle); Text(url.lastPathComponent).lineLimit(2).font(.caption) }.frame(height: 75).frame(maxWidth: .infinity).contentShape(Rectangle()).onTapGesture { open(url) }.contextMenu { actions(url) } } }.padding(8) } }
            }
            Divider(); HStack { Text("\(visible.count) items"); Spacer(); if let selected { Text(selected.lastPathComponent).lineLimit(1) } }.font(.caption).foregroundStyle(.secondary).padding(6)
        }.onAppear { perform { try WorkspaceFiles.prepare() }; refresh() }.onChange(of: hidden) { _,_ in refresh() }.onReceive(NotificationCenter.default.publisher(for: .zelquorinFilesChanged)) { _ in refresh() }
        .fileImporter(isPresented: $importing, allowedContentTypes: [.item], allowsMultipleSelection: true) { result in perform { for url in try result.get() { let access = url.startAccessingSecurityScopedResource(); defer { if access { url.stopAccessingSecurityScopedResource() } }; try FileManager.default.copyItem(at: url, to: WorkspaceFiles.unique(url.lastPathComponent, in: folder)) }; WorkspaceFiles.changed() } }
        .quickLookPreview($preview)
        .sheet(item: $editor) { item in TextFileEditor(url: item.url) }
        .sheet(item: $runner) { item in NavigationStack { TerminalApp(initialFile: item.url).navigationTitle(item.url.lastPathComponent) } }
        .sheet(item: $details) { item in VStack(alignment: .leading, spacing: 18) { Text(item.url.lastPathComponent).font(.title2); Text(item.url.path.replacingOccurrences(of: WorkspaceFiles.root.path, with: "Workspace")); Text(size(item.url)); Text(item.url.pathExtension.uppercased()); ShareLink(item: item.url); Spacer() }.padding(24).presentationDetents([.medium]) }
        .alert(action, isPresented: $askName) { TextField("Name", text: $name); Button("Cancel",role:.cancel) {}; Button("Save",action: createOrRename) }
        .alert("Delete item?", isPresented: $askDelete) { Button("Cancel",role:.cancel) {}; Button("Delete",role:.destructive) { perform { if let selected, selected != WorkspaceFiles.downloads, selected != WorkspaceFiles.documents { try FileManager.default.removeItem(at: selected); self.selected = nil; WorkspaceFiles.changed() } } } }
        .alert("Files", isPresented: Binding(get: { !error.isEmpty },set: { if !$0 { error = "" } })) { Button("OK") { error = "" } } message: { Text(error) }
    }
    private func place(_ label: String, _ icon: String, _ url: URL) -> some View { Button { navigate(url) } label: { Label(label,systemImage:icon).font(.caption).frame(maxWidth:.infinity,alignment:.leading).padding(5).background(folder == url ? Color.accentColor.opacity(0.2) : .clear) }.buttonStyle(.plain) }
    private func row(_ url: URL) -> some View { HStack { Image(systemName: WorkspaceFiles.directory(url) ? "folder.fill" : "doc").foregroundStyle(WorkspaceFiles.directory(url) ? Color.yellow : Color.secondary); Text(url.lastPathComponent).lineLimit(1); Spacer(); Text(size(url)).font(.caption).foregroundStyle(.secondary); Button { open(url) } label: { Image(systemName: "arrow.up.right.square") }.buttonStyle(.plain).accessibilityLabel("Open") }.padding(8).background(selected == url ? Color.accentColor.opacity(0.2) : .clear).contentShape(Rectangle()).onTapGesture(count:2) { open(url) }.onTapGesture { selected = url }.contextMenu { actions(url) } }
    @ViewBuilder private func actions(_ url: URL) -> some View { Button("Open") { open(url) }; if !WorkspaceFiles.directory(url) { Button("Edit as text") { editor = FileChoice(url:url) }; if url.pathExtension.lowercased() == "js" { Button("Open in Terminal") { runner = FileChoice(url:url) } }; ShareLink(item:url) { Label("Share",systemImage:"square.and.arrow.up") } }; Button("Copy") { clipboard = url; cut = false }; if url != WorkspaceFiles.downloads && url != WorkspaceFiles.documents { Button("Cut") { clipboard = url; cut = true }; Button("Rename") { selected = url; prompt("Rename",url.lastPathComponent) }; Button("Delete",role:.destructive) { selected = url; askDelete = true } }; Button("Properties") { details = FileChoice(url:url) } }
    private func open(_ url: URL) { guard WorkspaceFiles.inside(url) else { return }; if WorkspaceFiles.directory(url) { navigate(url) } else if url.pathExtension.lowercased() == "js" { runner = FileChoice(url:url) } else if ["txt","md","swift","py","c","cpp","java","rs","json","css","html","sh","yaml","yml","ts","go","rb","lua","sql"].contains(url.pathExtension.lowercased()) { editor = FileChoice(url:url) } else if QLPreviewController.canPreview(url as NSURL) { preview = url } else { details = FileChoice(url:url) } }
    private func size(_ url: URL) -> String { if WorkspaceFiles.directory(url) { return "Folder" }; return ByteCountFormatter.string(fromByteCount: Int64((try? url.resourceValues(forKeys:[.fileSizeKey]).fileSize) ?? 0), countStyle:.file) }
    private func navigate(_ url: URL) { guard WorkspaceFiles.inside(url), folder != url, WorkspaceFiles.directory(url) else { return }; back.append(folder); forward = []; folder = url; refresh() }
    private func refresh() { selected = nil; perform { files = try FileManager.default.contentsOfDirectory(at:folder,includingPropertiesForKeys:[.isDirectoryKey,.fileSizeKey,.contentModificationDateKey],options:hidden ? [] : [.skipsHiddenFiles]).filter { WorkspaceFiles.inside($0) } } }
    private func perform(_ work: () throws -> Void) { do { try work() } catch { self.error = error.localizedDescription } }
    private func prompt(_ a: String,_ n: String) { action=a; name=n; askName=true }
    private func createOrRename() { perform { let n = name.trimmingCharacters(in:.whitespacesAndNewlines); guard WorkspaceFiles.valid(n) else { throw CocoaError(.fileWriteInvalidFileName) }; let dest = folder.appendingPathComponent(n); guard !FileManager.default.fileExists(atPath:dest.path) else { throw CocoaError(.fileWriteFileExists) }; if action == "New folder" { try FileManager.default.createDirectory(at:dest,withIntermediateDirectories:false) } else if action == "Rename", let selected { try FileManager.default.moveItem(at:selected,to:dest) } else { try "".write(to:dest,atomically:true,encoding:.utf8) }; WorkspaceFiles.changed() } }
    private func paste() { perform { guard let source = clipboard, WorkspaceFiles.inside(source), !folder.path.hasPrefix(source.path + "/"), source != folder else { return }; let dest = WorkspaceFiles.unique(source.lastPathComponent,in:folder); if cut { try FileManager.default.moveItem(at:source,to:dest); clipboard=nil } else { try FileManager.default.copyItem(at:source,to:dest) }; WorkspaceFiles.changed() } }
}
struct TextFileEditor: View {
    let url: URL
    @State private var text = ""
    @State private var error = ""
    @State private var loaded = false
    @Environment(\.dismiss) private var dismiss
    var body: some View { NavigationStack { VStack { if !error.isEmpty { Text(error).foregroundStyle(.orange) }; TextEditor(text:$text).font(.system(.body,design:.monospaced)).autocorrectionDisabled().textInputAutocapitalization(.never).disabled(!loaded).padding() }.navigationTitle(url.lastPathComponent).toolbar { ToolbarItem(placement:.cancellationAction) { Button("Done") { dismiss() } }; ToolbarItem(placement:.confirmationAction) { Button("Save") { do { try text.write(to:url,atomically:true,encoding:.utf8); WorkspaceFiles.changed(); dismiss() } catch { self.error=error.localizedDescription } }.disabled(!loaded) } } }.onAppear { do { text=try WorkspaceFiles.text(url); loaded=true } catch { self.error=error.localizedDescription } } }
}
struct TerminalApp: View {
    var initialFile: URL? = nil
    @AppStorage("zelquorin.terminal.font") private var fontSize = 14.0
    @AppStorage("zelquorin.terminal.wrap") private var wrap = true
    @State private var command = ""
    @State private var script = "console.log('Hello, ZELQUORIN!');"
    @State private var output = "ZELQUORIN Terminal\nType help to get started.\n"
    @State private var cwd = WorkspaceFiles.root
    @State private var busy = false
    @State private var showEditor = false
    var body: some View {
        VStack(spacing: 6) {
            HStack { Text("Terminal").font(.headline); Spacer(); Button("JavaScript editor") { showEditor.toggle() }; Button("Clear") { output = "" } }.padding(8)
            if showEditor { TextEditor(text:$script).font(.system(size:fontSize,design:.monospaced)).autocorrectionDisabled().textInputAutocapitalization(.never).frame(minHeight:90,maxHeight:170); HStack { Text("Run code you trust").font(.caption).foregroundStyle(.secondary); Spacer(); Button("Run JavaScript") { execute(script) }.disabled(busy) }.padding(.horizontal,8) }
            ScrollViewReader { proxy in ScrollView(wrap ? [.vertical] : [.vertical,.horizontal]) { Text(output).font(.system(size:fontSize,design:.monospaced)).textSelection(.enabled).frame(maxWidth: .infinity,alignment:.leading).padding(8); Color.clear.frame(height:1).id("end") }.onChange(of:output) { _,_ in proxy.scrollTo("end",anchor:.bottom) } }
            HStack { Text("$ ").foregroundStyle(.green); TextField("Command",text:$command).font(.system(size:fontSize,design:.monospaced)).autocorrectionDisabled().textInputAutocapitalization(.never).onSubmit(run); Button("Run",action:run).disabled(busy) }.padding(8)
        }.background(Color.black.opacity(0.75)).onAppear { try? WorkspaceFiles.prepare(); if let initialFile { do { script=try WorkspaceFiles.text(initialFile); showEditor=true } catch { output += error.localizedDescription } } }
    }
    private func append(_ value: String) { output += value + "\n"; if output.count > 60000 { output=String(output.suffix(60000)) } }
    private func run() { guard !busy else { return }; let raw=command.trimmingCharacters(in:.whitespacesAndNewlines); guard !raw.isEmpty else { return }; command=""; append("$ " + raw); let parts=raw.split(separator:" ",maxSplits:1); let verb=String(parts[0]); let arg=parts.count>1 ? String(parts[1]) : ""; let path=cwd.appendingPathComponent(arg).standardizedFileURL
        do { switch verb { case "help": append("help, clear, pwd, ls, cd <folder>, cat <file>, mkdir <folder>, echo <text>, calc <expression>, js <code>, run <file.js>, languages\nPaths are relative to the workspace. JavaScript is evaluated locally."); case "clear":output=""; case "pwd":append(cwd.path.replacingOccurrences(of:WorkspaceFiles.root.path,with:"/workspace")); case "ls":append(try FileManager.default.contentsOfDirectory(atPath:cwd.path).sorted().joined(separator:"\n")); case "echo":append(arg); case "calc":append(String(try Arithmetic.evaluate(arg))); case "languages":append("JavaScript: executable (JavaScriptCore)\nText editing: Python, Swift, C/C++, Java, Rust, Go, Ruby, Lua, SQL, HTML/CSS and more. Native compilers are not installed."); case "js":execute(arg); case "run":guard path.pathExtension.lowercased()=="js" else { append("Only JavaScript scripts are executable here."); return }; script=try WorkspaceFiles.text(path); showEditor=true; append("Script loaded. Review it and select Run JavaScript."); case "cat":append(try WorkspaceFiles.text(path)); case "cd":guard WorkspaceFiles.inside(path),WorkspaceFiles.directory(path) else { append("Folder not found");return }; cwd=path; case "mkdir":guard WorkspaceFiles.valid(arg),WorkspaceFiles.inside(path) else { append("Invalid folder name");return }; try FileManager.default.createDirectory(at:path,withIntermediateDirectories:false); WorkspaceFiles.changed(); default:append("Command not found: " + verb) } } catch { append(error.localizedDescription) }
    }
    private func execute(_ code: String) { guard !busy, code.utf8.count <= 100_000 else { return }; busy=true
        DispatchQueue.global(qos:.userInitiated).async { var lines:[String]=[]; if let context=JSContext() { let logger: @convention(block) (String) -> Void = { value in if lines.count < 200 { lines.append(String(value.prefix(500))) } }; context.setObject(logger,forKeyedSubscript:"_zelLog" as NSString); context.exceptionHandler = { _,exception in lines.append("Error: " + (exception?.toString() ?? "Unknown error")) }; context.evaluateScript("var console={log:(...v)=>_zelLog(v.map(String).join(' '))}; var print=console.log;"); if let result=context.evaluateScript(code), !result.isUndefined { lines.append(String((result.toString() ?? "").prefix(2000))) } }; let result=lines.isEmpty ? "Done" : lines.joined(separator:"\n"); DispatchQueue.main.async { append(result); busy=false } }
    }
}
