import SwiftUI
import UIKit
import AVFoundation

// Continuous time-based rendering, not a frame sequence. Refresh rate is OS controlled.
struct BootAnimation: View {
    let closing: Bool
    let finished: () -> Void
    @AppStorage("zelquorin.boot.sound") private var startupSound = true
    @AppStorage("zelquorin.close.sound") private var closingSound = true
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var start = Date()
    @State private var player: AVAudioPlayer?
    var body: some View {
        GeometryReader { geo in
            TimelineView(.animation(minimumInterval: 1.0 / 120.0)) { timeline in
                let t = max(0, min(10, timeline.date.timeIntervalSince(start)))
                let fade = min(1, min(t / 2, (10 - t) / 2))
                let progress = min(1, max(0, (t - 2) / 6))
                let name = closing ? "ClosingLogo" : "StartupLogo"
                let logo = Image(name).resizable().aspectRatio(contentMode: .fit)
                let width = min(geo.size.width * 0.56, geo.size.height * 0.75)
                ZStack {
                    Color.black.ignoresSafeArea()
                    logo.frame(width: width)
                        .overlay {
                            if !reduceMotion {
                                GeometryReader { g in
                                    LinearGradient(stops: [.init(color: .clear, location: 0), .init(color: .white.opacity(0.35), location: 0.34), .init(color: .white, location: 0.5), .init(color: .white.opacity(0.35), location: 0.66), .init(color: .clear, location: 1)], startPoint: .leading, endPoint: .trailing)
                                        .frame(width: g.size.width * 0.32, height: g.size.height * 2)
                                        .rotationEffect(.degrees(22))
                                        .position(x: g.size.width * (-0.45 + 1.9 * progress), y: g.size.height / 2)
                                }.mask { logo.luminanceToAlpha() }.blendMode(.screen)
                            }
                        }.opacity(fade * fade * (3 - 2 * fade))
                }.frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }.accessibilityLabel(closing ? "Closing ZELQUORIN" : "Starting ZELQUORIN")
        .task {
            start = Date()
            if closing ? closingSound : startupSound {
                do {
                    if let asset = NSDataAsset(name: closing ? "ClosingTone" : "StartupTone") {
                        try AVAudioSession.sharedInstance().setCategory(.ambient, mode: .default)
                        player = try AVAudioPlayer(data: asset.data)
                        player?.play()
                    }
                } catch { /* visual animation remains available */ }
            }
            do { try await Task.sleep(for: .seconds(10)) } catch { return }
            player?.stop()
            finished()
        }.onDisappear { player?.stop() }
    }
}

// Low-volume, seamless synthesized ambience. Never plays in the background.
@MainActor final class DesktopAmbience: ObservableObject {
    private var player: AVAudioPlayer?
    func play(volume: Float) {
        if let player, player.isPlaying { player.volume = volume; return }
        do {
            guard let asset = NSDataAsset(name: "DesktopAmbience") else { return }
            try AVAudioSession.sharedInstance().setCategory(.ambient, mode: .default)
            let sound = try AVAudioPlayer(data: asset.data)
            sound.numberOfLoops = -1; sound.volume = 0; sound.prepareToPlay(); sound.play(); sound.setVolume(volume, fadeDuration: 1.0); player = sound
        } catch { player = nil }
    }
    func stop() { player?.stop(); player = nil }
}
