import SwiftUI
import WebKit
import UIKit

extension Notification.Name { static let zelquorinClearHistory = Notification.Name("zelquorin.browser.clearHistory"); static let zelquorinFilesChanged = Notification.Name("zelquorin.files.changed") }
struct WebEntry: Codable, Identifiable, Equatable {
    var id: String { url }
    let url: String
    let title: String
}
// Named browsing presets are not separate browser engines. All render through WebKit.
enum BrowserProfiles {
    static let names = ["ZELQUORIN", "Chrome-style", "Safari-style", "Firefox-style", "Opera-style", "Edge-style", "Brave-style", "Vivaldi-style", "DuckDuckGo-style", "Lynx-style text view"]
    static let engines = ["Google", "Bing", "DuckDuckGo", "Yahoo", "Brave Search", "Ecosia", "Startpage", "Qwant"]
    static func engine(_ name: String) -> String {
        switch name { case "Edge-style": return "Bing"; case "Brave-style": return "Brave Search"; case "Firefox-style", "DuckDuckGo-style", "Lynx-style text view": return "DuckDuckGo"; case "Vivaldi-style": return "Startpage"; case "Opera-style": return "Ecosia"; default: return "Google" }
    }
    static func home(_ name: String) -> String {
        switch engine(name) { case "Bing": return "https://www.bing.com/"; case "DuckDuckGo": return "https://duckduckgo.com/"; case "Brave Search": return "https://search.brave.com/"; case "Startpage": return "https://www.startpage.com/"; case "Ecosia": return "https://www.ecosia.org/"; default: return "https://www.google.com/" }
    }
    static func tint(_ name: String) -> Color {
        switch name { case "Chrome-style": return .green; case "Safari-style": return .blue; case "Firefox-style": return .orange; case "Opera-style": return .red; case "Edge-style": return .teal; case "Brave-style": return .orange; case "Vivaldi-style": return .pink; case "DuckDuckGo-style": return .yellow; case "Lynx-style text view": return .mint; default: return .accentColor }
    }
    static func desktop(_ name: String) -> Bool { name != "DuckDuckGo-style" }
    static func searchURL(_ query: String, engine: String) -> URL? {
        let base: String
        let key: String
        switch engine {
        case "Bing": base = "https://www.bing.com/search"; key = "q"
        case "DuckDuckGo": base = "https://duckduckgo.com/"; key = "q"
        case "Yahoo": base = "https://search.yahoo.com/search"; key = "p"
        case "Brave Search": base = "https://search.brave.com/search"; key = "q"
        case "Ecosia": base = "https://www.ecosia.org/search"; key = "q"
        case "Startpage": base = "https://www.startpage.com/sp/search"; key = "query"
        case "Qwant": base = "https://www.qwant.com/"; key = "q"
        default: base = "https://www.google.com/search"; key = "q"
        }
        var components = URLComponents(string: base); components?.queryItems = [URLQueryItem(name: key, value: query)]; return components?.url
    }
}
struct BrowserApp: View {
    @StateObject private var session = BrowserSession()
    @State private var panel = false
    @State private var options = false
    @State private var textPage: String?
    @AppStorage("zelquorin.browser.profile") private var browserProfile = "ZELQUORIN"
    @AppStorage("zelquorin.browser.desktop") private var desktopMode = true
    @AppStorage("zelquorin.browser.home") private var homepage = "https://www.google.com"
    @AppStorage("zelquorin.browser.search") private var engine = "Google"
    var body: some View {
        VStack(spacing: 0) {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 6) {
                    ForEach(session.tabs) { tab in
                        HStack(spacing: 6) {
                            Button { session.select(tab.id) } label: { Text(tab.title).lineLimit(1).frame(width: 105) }
                            Button { session.close(tab.id) } label: { Image(systemName: "xmark").font(.caption) }.accessibilityLabel("Close tab")
                        }.padding(8).background(session.selected == tab.id ? Color.accentColor.opacity(0.25) : Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 8))
                    }
                    Button { session.add() } label: { Image(systemName: "plus.circle").font(.title2) }.disabled(session.tabs.count >= 12).accessibilityLabel("New tab")
                }.padding(8)
            }
            HStack(spacing: 10) {
                Button { session.current?.web.goBack() } label: { Image(systemName: "chevron.left") }.disabled(!session.back).accessibilityLabel("Back")
                Button { session.current?.web.goForward() } label: { Image(systemName: "chevron.right") }.disabled(!session.forward).accessibilityLabel("Forward")
                Button { if session.loading { session.current?.web.stopLoading() } else { session.current?.web.reload() } } label: { Image(systemName: session.loading ? "xmark" : "arrow.clockwise") }.accessibilityLabel("Reload or stop")
                TextField("Search or enter HTTPS address", text: $session.address).textFieldStyle(.roundedBorder).keyboardType(.webSearch).textInputAutocapitalization(.never).autocorrectionDisabled().onSubmit { session.navigate(engine: engine) }
                Button("Go") { session.navigate(engine: engine) }.buttonStyle(.bordered)
                Button { options.toggle() } label: { Image(systemName: "ellipsis.circle").font(.title2) }.buttonStyle(.plain).accessibilityLabel("Browser options")
            }.padding(8)
            if options {
                ScrollView { VStack(alignment: .leading, spacing: 12) {
                    ChoiceRows(title: "Browser preset", choices: BrowserProfiles.names, selection: $browserProfile)
                    ChoiceRows(title: "Search engine", choices: BrowserProfiles.engines, selection: $engine)
                    Toggle("Desktop website", isOn: $desktopMode)
                    HStack { Button("Home") { session.open(homepage); options = false }; Button("Bookmark") { session.bookmark(); options = false }; Button("Library") { panel = true; options = false } }
                    Button("Read page as text") { showText(); options = false }
                    if let url = session.current?.web.url, url.scheme == "https" { ShareLink(item: url) { Label("Share page", systemImage: "square.and.arrow.up") } }
                }.padding(12) }.frame(maxHeight: 270).background(Color.black.opacity(0.3))
            }
            HStack { Text(browserProfile).font(.caption).foregroundStyle(BrowserProfiles.tint(browserProfile)); Spacer(); Text("Search: " + engine).font(.caption); Button { session.open("https://www.youtube.com/") } label: { Text("YouTube").font(.caption) } }.padding(.horizontal, 10).padding(.bottom, 5)
            if session.loading { ProgressView().progressViewStyle(.linear) }
            if !session.status.isEmpty { Text(session.status).font(.caption).foregroundStyle(.secondary).padding(6) }
            if let tab = session.current {
                ZStack { BrowserSurface(web: tab.web).id(tab.id).frame(maxWidth: .infinity, maxHeight: .infinity)
                if tab.web.url == nil && !session.loading && session.status.isEmpty {
                    VStack(spacing: 14) { Image(systemName: "globe").font(.system(size: 46, weight: .thin)); Text("ZELQUORIN Browser").font(.title.bold()); Button("Home") { session.open(homepage) }.buttonStyle(.bordered) }.frame(maxWidth: .infinity, maxHeight: .infinity)
                } }
            }
        }.tint(BrowserProfiles.tint(browserProfile)).onChange(of: browserProfile) { _, name in
            engine = BrowserProfiles.engine(name); homepage = BrowserProfiles.home(name); desktopMode = BrowserProfiles.desktop(name)
            textPage = nil; options = false; session.open(homepage)
        }.onChange(of: session.address) { _,_ in textPage = nil }.sheet(isPresented: Binding(get: { textPage != nil }, set: { if !$0 { textPage = nil } })) {
            NavigationStack { ScrollView { Text(textPage ?? "").frame(maxWidth: .infinity, alignment: .leading).padding() }.navigationTitle("Text view").toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { textPage = nil } } } }
        }.onChange(of: desktopMode) { _, mode in session.setDesktop(mode) }.onReceive(NotificationCenter.default.publisher(for: .zelquorinClearHistory)) { _ in session.history = [] }.sheet(isPresented: $panel) {
            NavigationStack { List {
                Section("Bookmarks") { if session.bookmarks.isEmpty { Text("No bookmarks yet").foregroundStyle(.secondary) }; ForEach(session.bookmarks) { entry in Button(entry.title) { session.open(entry.url); panel = false } } }
                Section("History") { if session.history.isEmpty { Text("No pages visited yet").foregroundStyle(.secondary) }; ForEach(session.history) { entry in Button(entry.title) { session.open(entry.url); panel = false } } }
                Section("Downloads") {  ForEach(session.completed, id: \.self) { url in if FileManager.default.fileExists(atPath: url.path) { ShareLink(item: url) { Label(url.lastPathComponent, systemImage: "doc") } } }; if session.completed.isEmpty { Text("No downloads in this session").foregroundStyle(.secondary) } }
            }.navigationTitle("Browser library").toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { panel = false } } } }
        }
    }
    private func showText() { session.current?.web.evaluateJavaScript("document.body ? document.body.innerText : ''") { result, error in if let text = result as? String { textPage = String(text.prefix(200_000)) } else { session.status = error?.localizedDescription ?? "Page text unavailable" } } }
}
struct BrowserSurface: UIViewRepresentable {
    let web: WKWebView
    func makeUIView(context: Context) -> WKWebView { web }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}
final class BrowserTab: Identifiable {
    let id = UUID()
    let web: WKWebView
    var title = "New tab"
    init(configuration: WKWebViewConfiguration? = nil) { let config = configuration ?? WKWebViewConfiguration(); if configuration == nil { config.websiteDataStore = .default() }; config.allowsInlineMediaPlayback = true; config.allowsPictureInPictureMediaPlayback = true; config.defaultWebpagePreferences.preferredContentMode = UserDefaults.standard.object(forKey: "zelquorin.browser.desktop") as? Bool == false ? .mobile : .desktop; web = WKWebView(frame: .zero, configuration: config) }
}
final class BrowserSession: NSObject, ObservableObject, WKNavigationDelegate, WKUIDelegate, WKDownloadDelegate {
    @Published var tabs: [BrowserTab] = []
    @Published var selected = UUID()
    @Published var address = ""
    @Published var loading = false
    @Published var back = false
    @Published var forward = false
    @Published var status = ""
    @Published var bookmarks: [WebEntry] = []
    @Published var history: [WebEntry] = []
    @Published var completed: [URL] = []
    private var destinations: [ObjectIdentifier: URL] = [:]
    private var downloads: [WKDownload] = []
    var current: BrowserTab? { tabs.first { $0.id == selected } }
    override init() { super.init(); bookmarks = read("zelquorin.browser.bookmarks"); history = read("zelquorin.browser.history"); add() }
    private func read(_ key: String) -> [WebEntry] { guard let data = UserDefaults.standard.data(forKey: key) else { return [] }; return (try? JSONDecoder().decode([WebEntry].self, from: data)) ?? [] }
    private func persist(_ values: [WebEntry], _ key: String) { if let data = try? JSONEncoder().encode(values) { UserDefaults.standard.set(data, forKey: key) } }
    func setDesktop(_ desktop: Bool) { if current?.web.isLoading == false { current?.web.reload() } }
    func add() { _ = addTab() }
    @discardableResult private func addTab(configuration: WKWebViewConfiguration? = nil) -> BrowserTab? { guard tabs.count < 12 else { return nil }; let tab = BrowserTab(configuration: configuration); tab.web.navigationDelegate = self; tab.web.uiDelegate = self; tabs.append(tab); select(tab.id); return tab }
    func select(_ id: UUID) { selected = id; sync(); status = "" }
    func close(_ id: UUID) { tabs.first { $0.id == id }?.web.stopLoading(); tabs.removeAll { $0.id == id }; if tabs.isEmpty { add() } else if selected == id { select(tabs.last!.id) } }
    func sync() { address = current?.web.url?.absoluteString ?? ""; loading = current?.web.isLoading ?? false; back = current?.web.canGoBack ?? false; forward = current?.web.canGoForward ?? false }
    func navigate(engine: String) {
        let raw = address.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !raw.isEmpty else { return }
        if raw.lowercased() == "youtube" { open("https://www.youtube.com"); return }
        if raw.contains("://") { open(raw); return }
        if !raw.contains(where: { $0.isWhitespace }), raw.contains(".") { open("https://" + raw); return }
        if let url = BrowserProfiles.searchURL(raw, engine: engine) { open(url.absoluteString) }
    }
    func open(_ raw: String) { guard let url = URL(string: raw), url.scheme?.lowercased() == "https", let host = url.host, !host.isEmpty, url.user == nil, url.password == nil else { status = "Enter a valid HTTPS website."; return }; status = ""; loading = true; current?.web.load(URLRequest(url: url)) }
    func bookmark() { guard let web = current?.web, let url = web.url, url.scheme == "https" else { return }; let entry = WebEntry(url: url.absoluteString, title: web.title ?? url.absoluteString); bookmarks.removeAll { $0.url == entry.url }; bookmarks.insert(entry, at: 0); persist(bookmarks, "zelquorin.browser.bookmarks"); status = "Bookmark saved" }
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) { if current?.web === webView { loading = true; status = "" } }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        if let tab = tabs.first(where: { $0.web === webView }) { tab.title = webView.title ?? "Website"; objectWillChange.send() }
        if let url = webView.url, url.scheme == "https" { let entry = WebEntry(url: url.absoluteString, title: webView.title ?? url.absoluteString); history.removeAll { $0.url == entry.url }; history.insert(entry, at: 0); history = Array(history.prefix(200)); persist(history, "zelquorin.browser.history") }
        if current?.web === webView { sync(); loading = false }
    }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { failed(webView, error) }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { failed(webView, error) }
    private func failed(_ web: WKWebView, _ error: Error) { if current?.web === web { loading = false; if (error as NSError).code != NSURLErrorCancelled { status = error.localizedDescription } } }
    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction, preferences: WKWebpagePreferences, decisionHandler: @escaping (WKNavigationActionPolicy, WKWebpagePreferences) -> Void) {
        preferences.preferredContentMode = UserDefaults.standard.object(forKey: "zelquorin.browser.desktop") as? Bool == false ? .mobile : .desktop
        guard let scheme = action.request.url?.scheme?.lowercased(), ["https", "about", "blob"].contains(scheme) else { status = "Only secure web navigation is supported."; decisionHandler(.cancel, preferences); return }
        if action.shouldPerformDownload { decisionHandler(.download, preferences); return }
        // Programmatic main-frame GET navigation avoids the usual universal-link handoff.
        // Do not rewrite form submissions, redirects, subframes or downloads.
        if scheme == "https", action.navigationType == .linkActivated, action.targetFrame?.isMainFrame == true, (action.request.httpMethod ?? "GET") == "GET" {
            decisionHandler(.cancel, preferences)
            let request = action.request
            DispatchQueue.main.async { webView.load(request) }
            return
        }
        decisionHandler(.allow, preferences)
    }
    func webView(_ webView: WKWebView, decidePolicyFor response: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) { let attachment = (response.response as? HTTPURLResponse)?.value(forHTTPHeaderField: "Content-Disposition")?.lowercased().contains("attachment") == true; decisionHandler(response.canShowMIMEType && !attachment ? .allow : .download) }
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? { guard navigationAction.targetFrame == nil, let url = navigationAction.request.url, ["https", "about"].contains(url.scheme ?? "") else { return nil }; return addTab(configuration: configuration)?.web }
    func webView(_ webView: WKWebView, navigationAction: WKNavigationAction, didBecome download: WKDownload) { accept(download) }
    func webView(_ webView: WKWebView, navigationResponse: WKNavigationResponse, didBecome download: WKDownload) { accept(download) }
    private func accept(_ download: WKDownload) { downloads.append(download); download.delegate = self; loading = false; status = "Downloading…" }
    func download(_ download: WKDownload, decideDestinationUsing response: URLResponse, suggestedFilename: String, completionHandler: @escaping (URL?) -> Void) {
        let name = (suggestedFilename as NSString).lastPathComponent.replacingOccurrences(of: "/", with: "_")
        guard !name.isEmpty, name != ".", name != ".." else { completionHandler(nil); return }
        // Downloads are files only. Never execute or install them.
        let folder = WorkspaceFiles.downloads
        do { try WorkspaceFiles.prepare(); guard WorkspaceFiles.inside(folder) else { throw CocoaError(.fileWriteNoPermission) }; let reserved = Set(destinations.values); var path = WorkspaceFiles.unique(name, in: folder); if reserved.contains(path) { path = WorkspaceFiles.unique(UUID().uuidString.prefix(8) + "-" + name, in: folder) }; destinations[ObjectIdentifier(download)] = path; completionHandler(path) }
        catch { status = error.localizedDescription; completionHandler(nil) }
    }
    func downloadDidFinish(_ download: WKDownload) { if let url = destinations.removeValue(forKey: ObjectIdentifier(download)) { completed.insert(url, at: 0); status = "Saved to ZELQUORIN Files: \(url.lastPathComponent)"; NotificationCenter.default.post(name: .zelquorinFilesChanged, object: nil) }; downloads.removeAll { $0 === download } }
    func download(_ download: WKDownload, didFailWithError error: Error, resumeData: Data?) { if let url = destinations.removeValue(forKey: ObjectIdentifier(download)) { try? FileManager.default.removeItem(at: url) }; downloads.removeAll { $0 === download }; status = error.localizedDescription }
}
